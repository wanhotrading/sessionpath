import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {nyObservation,scoreNY,METHODS,idx,csvCell} from '../ny-sessionpath-extension-core.mjs';
import {scoreEvents,LEVELS} from './core.mjs';

const OUT='outputs/ny-breakout-timing';
await fs.mkdir(OUT,{recursive:true});
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const sha=x=>createHash('sha256').update(typeof x==='string'?x:JSON.stringify(x)).digest('hex');
const hashFile=async p=>({path:p,sha256:createHash('sha256').update(await fs.readFile(p)).digest('hex')});
const CL=(await import('../seven-source-loader.mjs')).ordered;
const studyPaths={CL:'outputs/ny-sessionpath-extension/study.json',NQ:'outputs/ny-sessionpath-extension/study.json',ES:'outputs/es-ny-sessionpath-extension/study.json',GC:'outputs/gc-ny-sessionpath-extension/study.json'};
const modelPaths={NQ:'outputs/nq-model/research-days.json',ES:'outputs/es-model/research-days.json',GC:'outputs/gc-model/research-days.json'};
const forecastPaths={CL:'outputs/orange-box-fill/CL-clean-forecasts.json',NQ:'outputs/orange-box-fill/NQ-clean-forecasts.json',ES:'outputs/es-orange-box-fill/ES-clean-forecasts.json',GC:'outputs/gc-orange-box-fill/GC-clean-forecasts.json'};
const sourceManifest=[];
for(const p of [...new Set([...Object.values(studyPaths),...Object.values(modelPaths),...Object.values(forecastPaths),'work/seven-source-loader.mjs','work/ny-sessionpath-extension-core.mjs','work/ny-breakout-timing/core.mjs','work/ny-breakout-timing/extract.mjs','work/ny-breakout-timing/schema.json'])])sourceManifest.push(await hashFile(p));
const schema=await read('work/ny-breakout-timing/schema.json');
await fs.writeFile(OUT+'/schema.json',JSON.stringify(schema,null,2));
const config={version:1,created:'2026-11-02',markets:['CL','NQ','ES','GC'],methods:METHODS,primaryMethod:'nyOwnWide',primaryMinFit:50,levels:LEVELS,
 window:{start:510,end:960,timezone:'America/New_York',interval:5,bars:90},eventKinds:['WICK_FIRST','CLOSE_FIRST'],timeBins:'30-minute blocks of completed signal time;16:00 terminal separate',overshootBins:'10% of full box, floor, types separate',
 strictBreach:'high > upper +1e-9 or low < lower -1e-9; first close outside is strict close comparison',targetTouch:'Inclusive wick touch with 1e-9 arithmetic epsilon',
 eod:'Close of15:55bar, fully known16:00;16:00opening candleexcluded',pending:'All candles up tosignal plusnextopeningprice untouched and at least one laterbar. Laterwicktouch by16:00 counts.',
 noFutureFit:'Reuse frozen serialized Mean forecasts. Every saved cohort date is strictly earlier; cohort Mean reconstruction checked independently from source.',
 pooling:'Methods and alternative event definitions overlap dates and are never independent samples; no-break/ambiguous event rows preserved but excluded from side-specific tests.'};
await fs.writeFile(OUT+'/config.json',JSON.stringify(config,null,2));
const ev=await fs.open(OUT+'/events.jsonl','w'),tg=await fs.open(OUT+'/targets.jsonl','w'),ec=await fs.open(OUT+'/events.csv','w'),tc=await fs.open(OUT+'/targets.csv','w');
let eventFields=null,targetFields=null,eventCount=0,targetCount=0,parityChecks=0;
const summary={version:1,created:'2026-11-02',config,markets:{},files:{events:'events.jsonl',targets:'targets.jsonl',eventsCSV:'events.csv',targetsCSV:'targets.csv',schema:'schema.json',sourceManifest:'source-files.json'}};
const calendar={version:1,definition:'All source dates, including dates with no fitted forecast or outcome, retained as zero-contribution dates in calendar-block resampling.',markets:{},union:[]};
for(const market of config.markets){
 const days=market==='CL'?CL:await read(modelPaths[market]),dayMap=new Map(days.map(d=>[d.date,d]));
 calendar.markets[market]=days.map(d=>d.date);
 const priorStudy=await read(studyPaths[market]);
 const savedRows=priorStudy.rows.filter(r=>r.market===market),savedMap=new Map(savedRows.map(r=>[[r.date,r.method].join('|'),r]));
 const forecasts=(await read(forecastPaths[market])).filter(f=>METHODS.includes(f.variant));
 const sourceOHLC=new Map(days.map(d=>[d.date,sha({date:d.date,contract:d.contract,bars:d.bars})]));
 const history=new Map();
 for(const d of days){
  const o=nyObservation(d,{date:d.date,contract:d.contract,variant:'nyOwnWide',cases:1,meanUp:1,meanDown:1});
  if(o.error)continue;
  history.set(d.date,{up:Math.max(0,...o.future.map(b=>b.high-o.open))/d.avr,down:Math.max(0,...o.future.map(b=>o.open-b.low))/d.avr});
 }
 const exclusions=[],fitAudit=[],counts={},forecastDates=new Set();let scored=0,maxMeanError=0;
 for(const f of forecasts){
  assert.equal(f.mode,'earlier-only');assert.equal(new Set(f.cohortDates).size,f.cases);assert.equal(f.cohortDates.length,f.cases);assert(f.cohortDates.every(d=>d<f.date));
  const d=dayMap.get(f.date);if(!d){exclusions.push({date:f.date,method:f.variant,reason:'Missing source day'});continue;}
  const o=nyObservation(d,f);if(o.error){exclusions.push({date:f.date,method:f.variant,reason:o.error});continue;}
  const prior=f.cohortDates.map(date=>history.get(date));assert(prior.every(Boolean));
  const expectedUp=prior.reduce((s,p)=>s+p.up,0)/prior.length*d.avr,expectedDown=prior.reduce((s,p)=>s+p.down,0)/prior.length*d.avr;
  const maxError=Math.max(Math.abs(expectedUp-f.meanUp),Math.abs(expectedDown-f.meanDown));assert(maxError<1e-6);maxMeanError=Math.max(maxMeanError,maxError);
  const saved=savedMap.get([f.date,f.variant].join('|'));assert(saved,`No authoritative study row ${market} ${f.date} ${f.variant}`);
  for(const k of ['open','meanUp','meanDown','upper','lower','width'])assert.equal(o[k],saved[k],`Saved forecast ${k} mismatch`);
  const proof={cohortSHA256:sha(f.cohortDates),maxEarlierDate:f.cohortDates.reduce((a,b)=>a>b?a:b),sourceOHLC_SHA256:sourceOHLC.get(d.date),sourceLabel:d.source??'Archive/native audited source loader',studySource:studyPaths[market]};
  fitAudit.push({date:f.date,method:f.variant,n:f.cases,...proof,maxMeanError:maxError});
  const events=scoreEvents(o,{market,...proof});
  const old=scoreNY(o),wick=events[0];assert.equal(wick.side,old.firstSide);assert.equal(wick.signalOpenMinute,old.firstBar);assert.equal(wick.signalCloseMinute,old.confirmed);
  if(wick.side==='U'||wick.side==='D')for(let j=0;j<4;j++){
   const a=wick.targets[j],b=old.levels[j].firstTarget;
   assert.equal(a.touchedThroughSignal,b.alreadyBeforeConfirmation);assert.equal(a.nextOpenGap,b.gapAtNextOpen);assert.equal(a.pending,b.pending);assert.equal(a.pending&&a.pendingHit,b.pendingHit);parityChecks+=4;
  }
  for(const event of events){
   assert(event.eodClose===o.future[89].close);assert.equal(event.eodCloseKnownMinute,960);
   if(event.side==='U'||event.side==='D'){
    assert(event.signalCloseMinute>=515&&event.signalCloseMinute<=960);assert.equal(event.minutesRemaining,(89-event.signalIndex)*5);
    assert(event.targets.every(t=>!t.pending||(event.laterBars>0&&!t.touchedThroughSignal&&!t.nextOpenGap)));
    assert(event.targets.every(t=>!t.pendingHit||t.laterHitCloseMinute>event.signalCloseMinute&&t.laterHitCloseMinute<=960));
   }
   counts[[event.eventKind,event.side,event.type].join('|')]=(counts[[event.eventKind,event.side,event.type].join('|')]||0)+1;
   const {targets,...flat}=event;
   if(!eventFields){eventFields=Object.keys(flat);await ec.write(eventFields.join(',')+'\r\n');}
   await ev.write(JSON.stringify(event)+'\n');await ec.write(eventFields.map(k=>csvCell(flat[k])).join(',')+'\r\n');eventCount++;
   for(const target of targets){
    const tr={eventId:event.eventId,market,date:event.date,year:event.year,contract:event.contract,method:event.method,n:event.n,eventKind:event.eventKind,side:event.side,type:event.type,timeBlock:event.timeBlock,signalCloseMinute:event.signalCloseMinute,minutesRemaining:event.minutesRemaining,wickOvershoot:event.wickOvershoot,closeOvershoot:event.closeOvershoot,closeOvershootBin:event.closeOvershootBin,eodState:event.eodState,maxLaterSameSideOvershoot:event.maxLaterSameSideOvershoot,...target};
    if(!targetFields){targetFields=Object.keys(tr);await tc.write(targetFields.join(',')+'\r\n');}
    await tg.write(JSON.stringify(tr)+'\n');await tc.write(targetFields.map(k=>csvCell(tr[k])).join(',')+'\r\n');targetCount++;
   }
  }
  scored++;forecastDates.add(f.date);
 }
 assert.equal(scored,savedRows.length,`${market} did not reproduce all authoritative study rows`);
 await fs.writeFile(`${OUT}/${market}-fit-audit.json`,JSON.stringify(fitAudit));
 summary.markets[market]={sourceDates:days.length,from:days[0].date,to:days.at(-1).date,forecasts:forecasts.length,scoredForecasts:scored,uniqueForecastDates:forecastDates.size,maxMeanReconstructionError:maxMeanError,counts,exclusions,canonicalOHLC_SHA256:sha(days.map(d=>({date:d.date,sha256:sourceOHLC.get(d.date)}))),sourceStudySHA256:sourceManifest.find(s=>s.path===studyPaths[market]).sha256};
 console.log(JSON.stringify({market,scored,exclusions:exclusions.length,eventCount,targetCount}));
}
await Promise.all([ev.close(),tg.close(),ec.close(),tc.close()]);
calendar.union=[...new Set(Object.values(calendar.markets).flat())].sort();
await fs.writeFile(OUT+'/calendar.json',JSON.stringify(calendar,null,2));
summary.qa={events:eventCount,targets:targetCount,oldTargetParityAssertions:parityChecks,earlierOnlyCohortProof:true,allSerializedBoxesMatchPriorStudy:true,finalBarEndpointChecked:true};
await fs.writeFile(OUT+'/source-files.json',JSON.stringify(sourceManifest,null,2));
await fs.writeFile(OUT+'/extraction-summary.json',JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary.qa));
