"""Second-pass arithmetic audit using source events and the saved prediction ledger."""
import collections
import csv
import json
import math
from pathlib import Path

OUT = Path("outputs/ny-breakout-timing")
events = [json.loads(line) for line in (OUT / "events.jsonl").read_text(encoding="utf-8").splitlines()]
result = json.loads((OUT / "analysis.json").read_text(encoding="utf-8"))
with (OUT / "walk-forward-predictions.csv").open(encoding="utf-8-sig", newline="") as handle:
    predictions = list(csv.DictReader(handle))
states = ["INSIDE", "SAME_SIDE", "OPPOSITE_SIDE"]
checks = 0


def category(row, model):
    strength = "CLOSED_INSIDE" if row["type"] == "WICK_ONLY" else str(round(row["closeOvershootBin"] * 100)) + "%"
    if model == "time_block":
        return str(row["timeBlock"])
    if model == "close_strength":
        return strength
    return str(row["timeBlock"]) + ";" + strength


def outcome_value(row, outcome):
    if outcome == "eod3":
        return [int(row["eodState"] == s) for s in states] if row.get("minutesRemaining", 0) > 0 and row.get("eodState") in states else None
    target = next(t for t in row["targets"] if abs(t["multiple"] - 1.5) < 1e-8)
    return int(target["pendingHit"]) if target["pending"] else None


primary = [e for e in events if e["method"] == "nyOwnWide" and e["n"] >= 50 and e["eventKind"] == "WICK_FIRST" and e["side"] in ["U", "D"]]
by_id = {e["eventId"]: e for e in primary}
groups = collections.defaultdict(list)
for e in primary:
    groups[e["market"]].append(e)
seen = set()
for p in predictions:
    row = by_id[p["eventId"]]
    key = (p["eventId"], p["outcome"], p["model"])
    assert key not in seen
    seen.add(key)
    history = [(e, outcome_value(e, p["outcome"])) for e in groups[p["market"]] if e["date"] < p["date"] and e["side"] == p["side"] and e["type"] == p["type"]]
    history = [(e, y) for e, y in history if y is not None]
    local = [(e, y) for e, y in history if category(e, p["model"]) == p["category"]]
    assert len(history) == int(p["base_n"]) >= 50
    assert len(local) == int(p["local_n"])
    assert category(row, p["model"]) == p["category"]
    y = outcome_value(row, p["outcome"])
    assert json.loads(p["y"]) == y
    dim = 2 if p["outcome"] == "pending150" else 3
    wins = [sum((int(yy == j) if dim == 2 else yy[j]) for _, yy in history) for j in range(dim)]
    local_wins = [sum((int(yy == j) if dim == 2 else yy[j]) for _, yy in local) for j in range(dim)]
    base = [(v + 1) / (len(history) + dim) for v in wins]
    candidate = [(local_wins[j] + 20 * base[j]) / (len(local) + 20) for j in range(dim)]
    for name, expected in [("p_base", base[1] if dim == 2 else base), ("p_candidate", candidate[1] if dim == 2 else candidate)]:
        actual = json.loads(p[name])
        error = abs(expected - actual) if dim == 2 else max(abs(a - b) for a, b in zip(expected, actual))
        assert error < 1e-12
        checks += 1
    checks += 5

for comparison in result["comparisons"]:
    pp = [p for p in predictions if all(p[k] == comparison[k] for k in ["market", "outcome", "model"])]
    gains, base_losses, candidate_losses = [], [], []
    for p in pp:
        y, base, candidate = (json.loads(p[k]) for k in ["y", "p_base", "p_candidate"])
        if isinstance(y, list):
            b = sum((b - yy) ** 2 for b, yy in zip(base, y))
            c = sum((q - yy) ** 2 for q, yy in zip(candidate, y))
        else:
            b, c = (base - y) ** 2, (candidate - y) ** 2
        base_losses.append(b)
        candidate_losses.append(c)
        gains.append(b - c)
    assert len(pp) == comparison["n"]
    for label, values in [("gain", gains), ("base_brier", base_losses), ("candidate_brier", candidate_losses)]:
        assert abs(sum(values) / len(values) - comparison[label]) < 1e-12
        checks += 1
    ids_by_model = [{p["eventId"] for p in predictions if p["market"] == comparison["market"] and p["outcome"] == comparison["outcome"] and p["model"] == model} for model in ["time_block", "close_strength", "time_strength"]]
    assert ids_by_model[0] == ids_by_model[1] == ids_by_model[2]
    checks += 2

ordered = sorted(result["comparisons"], key=lambda c: c["bootstrap"]["p"])
previous = 0
for i, comparison in enumerate(ordered):
    previous = max(previous, min(1, (24 - i) * comparison["bootstrap"]["p"]))
    assert abs(previous - comparison["holm_p"]) < 1e-15
    checks += 1

receipt = dict(status="PASS", arithmetic_checks=checks, saved_predictions=len(predictions), all24_comparisons_checked=True, source_recomputed_strict_prior_counts=True, candidate_fixed20_prior_verified=True, fair_paired_event_sets=True, multiclass_brier_unscaled=True, holm24_verified=True, primary_bootstrap_seed=result["comparisons"][0]["bootstrap"]["seed"], limitation="Independent arithmetic rescore within the same study, not an external data replication.")
(OUT / "analysis-audit.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(json.dumps(receipt, indent=2))
