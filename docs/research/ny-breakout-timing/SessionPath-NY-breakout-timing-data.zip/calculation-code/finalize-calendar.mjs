// Add the complete source calendar to an already audited extraction without rewriting event files.
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {ordered as CL} from '../seven-source-loader.mjs';
const out='outputs/ny-breakout-timing';
const calendar={version:1,definition:'All source dates, including dates with no fitted forecast or outcome, retained as zero-contribution dates in calendar-block resampling.',markets:{CL:CL.map(d=>d.date)},union:[]};
for(const m of ['NQ','ES','GC'])calendar.markets[m]=JSON.parse(await fs.readFile(`outputs/${m.toLowerCase()}-model/research-days.json`,'utf8')).map(d=>d.date);
calendar.union=[...new Set(Object.values(calendar.markets).flat())].sort();
await fs.writeFile(out+'/calendar.json',JSON.stringify(calendar,null,2));
const manifest=JSON.parse(await fs.readFile(out+'/source-files.json','utf8'));
for(const row of manifest)row.sha256=createHash('sha256').update(await fs.readFile(row.path)).digest('hex');
manifest.push({path:'work/ny-breakout-timing/finalize-calendar.mjs',sha256:createHash('sha256').update(await fs.readFile('work/ny-breakout-timing/finalize-calendar.mjs')).digest('hex')});
await fs.writeFile(out+'/source-files.json',JSON.stringify(manifest,null,2));
console.log(JSON.stringify({markets:Object.fromEntries(Object.entries(calendar.markets).map(([m,a])=>[m,a.length])),union:calendar.union.length}));
