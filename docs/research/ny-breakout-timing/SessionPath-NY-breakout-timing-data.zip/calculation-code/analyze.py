"""Prespecified NY first-breakout timing/strength analysis. No live model changes."""
import argparse
import collections
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

SEED = 20261102
MARKETS = ["CL", "NQ", "ES", "GC"]
METHODS = ["nyOwnWide", "nyOwnExact", "nyPriorWide", "nyPriorExact"]
MODELS = ["time_block", "close_strength", "time_strength"]
STATES = ["INSIDE", "SAME_SIDE", "OPPOSITE_SIDE"]
ALPHA = 20


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def write_csv(path, rows):
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for k, v in row.items()})


def rate(values):
    values = [bool(x) for x in values if x is not None]
    n, k = len(values), sum(values)
    if not n:
        return dict(n=0, k=0, p=None, lo=None, hi=None)
    p, z = k / n, 1.95996398454
    scale = 1 + z * z / n
    center = (p + z * z / (2 * n)) / scale
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / scale
    return dict(n=n, k=k, p=p, lo=max(0.0, center - half), hi=min(1.0, center + half))


def distribution(values):
    values = [float(x) for x in values if x is not None and math.isfinite(float(x))]
    if not values:
        return dict(n=0, mean=None, median=None, p25=None, p75=None, p90=None)
    return dict(n=len(values), mean=float(np.mean(values)), median=float(np.median(values)), p25=float(np.quantile(values, .25)), p75=float(np.quantile(values, .75)), p90=float(np.quantile(values, .90)))


def target(row, multiple=1.5):
    return next((t for t in row.get("targets", []) if abs(float(t["multiple"]) - multiple) < 1e-8), None)


def strength_key(row):
    if row["type"] == "WICK_ONLY":
        return "CLOSED_INSIDE"
    if row.get("closeOvershootBin") is None:
        return None
    # The extracted bin is a fraction of full box width, not a 1.xx range multiple.
    return f"{round(float(row['closeOvershootBin']) * 100):d}%"


def time_label(value):
    value = int(value)
    return f"{value // 60:02d}:{value % 60:02d}" if value != 960 else "16:00_ENDPOINT_ONLY"


def describe(rows):
    resolved = [r for r in rows if r.get("side") in ("U", "D")]
    remaining = [r for r in resolved if r.get("minutesRemaining", 0) > 0]
    levels = sorted({float(t["multiple"]) for r in resolved for t in r.get("targets", [])})
    result = dict(events=len(rows), resolved=len(resolved), ambiguous=sum(r.get("side") == "AMBIGUOUS" for r in rows), no_break=sum(r.get("side") == "NONE" for r in rows), endpoint_only=sum(r.get("signalCloseMinute") == 960 for r in resolved), wick_only=sum(r.get("type") == "WICK_ONLY" for r in resolved), close_outside=sum(r.get("type") == "CLOSE_OUTSIDE" for r in resolved), fit_below50=sum(r.get("n", 0) < 50 for r in rows), eod={s: rate([r.get("eodState") == s for r in resolved if r.get("eodState") in STATES]) for s in STATES})
    result["eod_future_only"] = {s: rate([r.get("eodState") == s for r in remaining if r.get("eodState") in STATES]) for s in STATES}
    result["max_later_multiple"] = distribution([1 + r["maxLaterSameSideOvershoot"] for r in remaining if r.get("maxLaterSameSideOvershoot") is not None])
    result["max_later_multiple_unclipped"] = distribution([r.get("maxLaterSameSideMultiple") for r in remaining])
    result["max_session_multiple_including_trigger"] = distribution([1 + r["maxSessionSameSideOvershoot"] for r in resolved if r.get("maxSessionSameSideOvershoot") is not None])
    result["additional_beyond_signal_extreme"] = distribution([r.get("additionalBeyondSignalExtreme") for r in remaining])
    result["final_signed_from_open_width"] = distribution([r.get("finalSignedFromOpen") for r in resolved])
    result["final_side_multiple"] = distribution([r.get("finalSideMultiple") for r in resolved])
    result["closing_overshoot_width"] = distribution([r.get("closeOvershoot") for r in resolved if r["type"] == "CLOSE_OUTSIDE"])
    result["wick_overshoot_width"] = distribution([r.get("wickOvershoot") for r in resolved])
    result["eod_drift_from_signal_close_width"] = distribution([(r["eodClose"] - r["signalClose"]) * (1 if r["side"] == "U" else -1) / r["width"] for r in remaining if all(r.get(k) is not None for k in ["eodClose", "signalClose", "width"]) and r["width"] > 0])
    result["targets"] = []
    for multiple in levels:
        pairs = [(r, target(r, multiple)) for r in resolved]
        pairs = [(r, t) for r, t in pairs if t is not None]
        pending = [t for _, t in pairs if t.get("pending")]
        result["targets"].append(dict(multiple=multiple, trigger_reached=rate([t.get("triggerReached") for _, t in pairs]), touched_before_first_close=sum(bool(t.get("touchedBeforeFirstClose")) for _, t in pairs), next_open_gap=sum(bool(t.get("nextOpenGap")) for _, t in pairs), no_remaining=sum(bool(t.get("noRemaining")) for _, t in pairs), pending_hit=rate([t.get("pendingHit") for t in pending]), pending_miss=rate([not t.get("pendingHit") for t in pending])))
    return result


def flatten_descriptive(meta, stats):
    result = dict(meta)
    for key, value in stats.items():
        if key == "targets":
            for t in value:
                suffix = str(round(t["multiple"] * 100))
                for name, field in t.items():
                    if name == "multiple":
                        continue
                    if isinstance(field, dict):
                        for q, number in field.items():
                            result[f"target{suffix}_{name}_{q}"] = number
                    else:
                        result[f"target{suffix}_{name}"] = field
        elif isinstance(value, dict):
            for subkey, subvalue in value.items():
                if isinstance(subvalue, dict):
                    for detail, number in subvalue.items():
                        result[f"{key}_{subkey}_{detail}"] = number
                else:
                    result[f"{key}_{subkey}"] = subvalue
        else:
            result[key] = value
    return result


def score(predictions):
    if not predictions:
        return dict(n=0, gain=None, base_brier=None, candidate_brier=None, base_logloss=None, candidate_logloss=None, sparse_local_fraction=None)
    base = np.array([p["p_base"] for p in predictions], dtype=float)
    candidate = np.array([p["p_candidate"] for p in predictions], dtype=float)
    y = np.array([p["y"] for p in predictions], dtype=float)
    binary = y.ndim == 1
    brier = lambda p: (p - y) ** 2 if binary else np.sum((p - y) ** 2, axis=1)
    ll = lambda p: float(np.mean(-y * np.log(np.clip(p, 1e-12, 1 - 1e-12)) - (1 - y) * np.log(np.clip(1 - p, 1e-12, 1 - 1e-12)))) if binary else float(np.mean(-np.sum(y * np.log(np.clip(p, 1e-12, 1)), axis=1)))
    def calibration(p):
        if not binary:
            return {state: float(np.mean(p[:, j] - y[:, j])) for j, state in enumerate(STATES)}
        return float(np.mean(p - y))
    def ece(p):
        if not binary:
            return {state: ece_binary(p[:, j], y[:, j]) for j, state in enumerate(STATES)}
        return ece_binary(p, y)
    b, c = brier(base), brier(candidate)
    return dict(n=len(predictions), gain=float(np.mean(b - c)), base_brier=float(np.mean(b)), candidate_brier=float(np.mean(c)), relative_brier_reduction=float(np.mean(b - c) / np.mean(b)) if np.mean(b) > 0 else None, base_logloss=ll(base), candidate_logloss=ll(candidate), base_calibration_bias=calibration(base), candidate_calibration_bias=calibration(candidate), base_ece=ece(base), candidate_ece=ece(candidate), mean_local_train_n=float(np.mean([p["local_n"] for p in predictions])), sparse_local_fraction=float(np.mean([p["local_n"] < 20 for p in predictions])))


def ece_binary(p, y):
    total = 0.0
    for i in range(10):
        mask = (p >= i / 10) & (p < (i + 1) / 10 if i < 9 else p <= 1)
        if np.any(mask):
            total += float(np.mean(mask) * abs(np.mean(p[mask]) - np.mean(y[mask])))
    return total


def bootstrap(predictions, calendar, indices):
    if not predictions:
        return dict(lo=None, hi=None, p=None, reps=0)
    positions = {date: i for i, date in enumerate(calendar)}
    sums, counts = np.zeros(len(calendar)), np.zeros(len(calendar))
    for row in predictions:
        b, c, y = np.array(row["p_base"]), np.array(row["p_candidate"]), np.array(row["y"])
        gain = float(np.sum((b - y) ** 2) - np.sum((c - y) ** 2))
        pos = positions[row["date"]]
        sums[pos] += gain
        counts[pos] += 1
    denominator = counts[indices].sum(axis=1)
    values = sums[indices].sum(axis=1)[denominator > 0] / denominator[denominator > 0]
    if not len(values):
        return dict(lo=None, hi=None, p=None, reps=0)
    gain = float(sums.sum() / counts.sum())
    lo, hi = np.quantile(values, [.025, .975])
    p = (1 + np.sum(np.abs(values - gain) >= abs(gain))) / (len(values) + 1)
    return dict(lo=float(lo), hi=float(hi), p=float(p), reps=len(values))


def predictions_for(rows, outcome, model):
    eligible = []
    exclusions = collections.Counter()
    for row in rows:
        if row.get("side") not in ("U", "D"):
            exclusions["unresolved_or_no_break"] += 1
            continue
        if outcome == "pending150":
            t = target(row)
            if t is None or not t.get("pending"):
                exclusions["target_not_pending"] += 1
                continue
            y = int(bool(t["pendingHit"]))
        else:
            if row.get("minutesRemaining", 0) <= 0:
                exclusions["eod_already_known_at_endpoint"] += 1
                continue
            if row.get("eodState") not in STATES:
                exclusions["eod_unavailable"] += 1
                continue
            y = [int(row["eodState"] == state) for state in STATES]
        if row.get("timeBlock") is None or strength_key(row) is None:
            exclusions["missing_predictor"] += 1
            continue
        eligible.append((row, y))
    assert len({row["date"] for row, _ in eligible}) == len(eligible), "One primary event per market/method/date required"
    dimensions = 2 if outcome == "pending150" else 3
    base, local = {}, {}
    pp = []
    for row, y in sorted(eligible, key=lambda pair: pair[0]["date"]):
        bk = (row["side"], row["type"])
        category = (str(row["timeBlock"]),) if model == "time_block" else (strength_key(row),) if model == "close_strength" else (str(row["timeBlock"]), strength_key(row))
        lk = bk + category
        bcounts = base.setdefault(bk, np.zeros(dimensions, dtype=int))
        lcounts = local.setdefault(lk, np.zeros(dimensions, dtype=int))
        n, ln = int(bcounts.sum()), int(lcounts.sum())
        p = (bcounts + 1) / (n + dimensions)
        q = (lcounts + ALPHA * p) / (ln + ALPHA)
        if row["date"] >= "2024-01-01" and n >= 50:
            pp.append(dict(market=row["market"], method=row["method"], eventKind=row["eventKind"], outcome=outcome, model=model, date=row["date"], eventId=row["eventId"], side=row["side"], type=row["type"], category=";".join(category), timeBlock=row["timeBlock"], strength=strength_key(row), n=row["n"], y=y, p_base=float(p[1]) if dimensions == 2 else p.tolist(), p_candidate=float(q[1]) if dimensions == 2 else q.tolist(), base_n=n, local_n=ln))
        # Updates occur only after prediction; each row is a different date.
        if dimensions == 2:
            bcounts[y] += 1
            lcounts[y] += 1
        else:
            bcounts += np.array(y)
            lcounts += np.array(y)
    return pp, dict(exclusions)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", default="outputs/ny-breakout-timing/events.jsonl")
    parser.add_argument("--output", default="outputs/ny-breakout-timing")
    parser.add_argument("--calendar", default="outputs/ny-breakout-timing/calendar.json")
    parser.add_argument("--reps", type=int, default=3000)
    args = parser.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    path = Path(args.events)
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    assert rows and all(row["market"] in MARKETS and row["method"] in METHODS for row in rows)
    calendar_path = Path(args.calendar)
    calendar_data = json.loads(calendar_path.read_text(encoding="utf-8-sig")) if calendar_path.exists() else None
    if isinstance(calendar_data, dict):
        calendar_data = calendar_data.get("union", calendar_data.get("dates", calendar_data.get("calendar")))
    calendar = sorted({date for date in calendar_data if date >= "2024-01-01"}) if isinstance(calendar_data, list) else sorted({row["date"] for row in rows if row["date"] >= "2024-01-01"})
    assert all(row["date"] in calendar for row in rows if row["date"] >= "2024-01-01"), "Calendar must retain every event date"
    assert len(calendar) > 20
    indices = {}
    for block in [5, 10, 20]:
        rng = np.random.default_rng(SEED if block == 10 else SEED + block)
        starts = rng.integers(0, len(calendar), size=(args.reps, math.ceil(len(calendar) / block)))
        indices[block] = ((starts[:, :, None] + np.arange(block)) % len(calendar)).reshape(args.reps, -1)[:, :len(calendar)].astype(np.int32)
    groups, descriptive_rows, descriptive_cells = [], [], []
    for market in MARKETS:
        for method in METHODS:
            for fit_label, minimum in [("fit50", 50), ("all_positive_fit", 1)]:
                for event_kind in ["WICK_FIRST", "CLOSE_FIRST"]:
                    selected = [r for r in rows if r["market"] == market and r["method"] == method and r["n"] >= minimum and r["eventKind"] == event_kind]
                    meta = dict(market=market, method=method, fit=fit_label, eventKind=event_kind)
                    stats = describe(selected)
                    groups.append({**meta, **stats})
                    descriptive_rows.append(flatten_descriptive({**meta, "group": "ALL", "category": "ALL", "side": "ALL"}, stats))
                    # All earlier-only methods are described; only OwnWide fit50 enters primary testing.
                    for side in ["ALL", "U", "D"]:
                        sr = [r for r in selected if r["side"] in ("U", "D") and (side == "ALL" or r["side"] == side)]
                        for group, key in [("time", lambda r: time_label(r["timeBlock"])), ("strength", strength_key), ("year", lambda r: r["date"][:4])]:
                            cats = sorted({key(r) for r in sr if key(r) is not None})
                            for category in cats:
                                rr = [r for r in sr if key(r) == category]
                                cell_meta = {**meta, "group": group, "category": category, "side": side}
                                cell_stats = describe(rr)
                                descriptive_rows.append(flatten_descriptive(cell_meta, cell_stats))
                                descriptive_cells.append({**cell_meta, **cell_stats})
    comparisons, annual, predictions = [], [], []
    for market in MARKETS:
        selected = [r for r in rows if r["market"] == market and r["method"] == "nyOwnWide" and r["n"] >= 50 and r["eventKind"] == "WICK_FIRST"]
        for outcome in ["pending150", "eod3"]:
            all_model_ids = None
            for model in MODELS:
                pp, exclusions = predictions_for(selected, outcome, model)
                ids = [(p["date"], p["eventId"]) for p in pp]
                if all_model_ids is None:
                    all_model_ids = ids
                assert ids == all_model_ids, "All timing/strength candidates require identical paired test events"
                stats = score(pp)
                boots = {str(block): {**bootstrap(pp, calendar, ix), "block": block, "seed": SEED if block == 10 else SEED + block} for block, ix in indices.items()}
                ys = []
                for year in ["2024", "2025", "2026"]:
                    yr = dict(market=market, method="nyOwnWide", outcome=outcome, model=model, year=year, **score([p for p in pp if p["date"].startswith(year)]))
                    annual.append(yr)
                    ys.append(yr)
                comparisons.append(dict(market=market, method="nyOwnWide", outcome=outcome, model=model, primary=True, **stats, bootstrap=boots["10"], block_sensitivity={key: value for key, value in boots.items() if key != "10"}, late2025=score([p for p in pp if p["date"] >= "2025-01-01"]), annual=ys, exclusions=exclusions))
                predictions.extend(pp)
    # All 24 prespecified primary comparisons remain in the multiplicity family.
    assert len(comparisons) == len(MARKETS) * len(MODELS) * 2 == 24
    ordered = sorted(comparisons, key=lambda r: r["bootstrap"]["p"] if r["bootstrap"]["p"] is not None else 1.0)
    previous = 0.0
    for i, row in enumerate(ordered):
        raw = row["bootstrap"]["p"]
        previous = max(previous, min(1.0, (len(ordered) - i) * (raw if raw is not None else 1.0)))
        row["holm_p"] = previous
    for row in comparisons:
        positive_years = sum(y["n"] >= 30 and y["gain"] is not None and y["gain"] > 0 for y in row["annual"])
        row["annual_positive_years_n30"] = positive_years
        supported = row["n"] >= 100 and row["bootstrap"]["lo"] is not None and row["bootstrap"]["lo"] > 0 and row["holm_p"] < .05 and row["late2025"]["gain"] is not None and row["late2025"]["gain"] > 0 and positive_years >= 2
        row["classification"] = "SUPPORTED" if supported else "TENTATIVE" if row["gain"] is not None and row["gain"] > 0 else "NO_IMPROVEMENT"
        row["block5_and20_positive_ci"] = all(b["lo"] is not None and b["lo"] > 0 for b in row["block_sensitivity"].values())
    sensitivity = []
    for market in MARKETS:
        for method in METHODS:
            for fit_label, minimum in [("fit50", 50), ("all_positive_fit", 1)]:
                if method == "nyOwnWide" and minimum == 50:
                    continue
                selected = [r for r in rows if r["market"] == market and r["method"] == method and r["n"] >= minimum and r["eventKind"] == "WICK_FIRST"]
                for outcome in ["pending150", "eod3"]:
                    for model in MODELS:
                        pp, _ = predictions_for(selected, outcome, model)
                        sensitivity.append(dict(market=market, method=method, fit=fit_label, outcome=outcome, model=model, **score(pp), exploratory=True))
    calibration = []
    for market in MARKETS:
        for outcome in ["pending150", "eod3"]:
            for model in MODELS:
                selected = [p for p in predictions if p["market"] == market and p["outcome"] == outcome and p["model"] == model]
                for basis in ["base", "candidate"]:
                    for state in (["HIT150"] if outcome == "pending150" else STATES):
                        j = STATES.index(state) if state in STATES else None
                        values = [(p["p_" + basis] if j is None else p["p_" + basis][j], p["y"] if j is None else p["y"][j]) for p in selected]
                        for band in range(10):
                            items = [(p, y) for p, y in values if p >= band / 10 and (p < (band + 1) / 10 if band < 9 else p <= 1)]
                            if items:
                                calibration.append(dict(market=market, outcome=outcome, model=model, basis=basis, state=state, band_lower=band / 10, band_upper=(band + 1) / 10, n=len(items), mean_prediction=float(np.mean([p for p, _ in items])), observed_rate=rate([y for _, y in items])))
    result = dict(created="2026-11-02", study="NY breakout timing and closing overshoot", source=str(path), source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), calendar_source=str(calendar_path) if calendar_path.exists() else "event dates fallback", seed=SEED, bootstrap_reps=args.reps, calendar_dates=len(calendar), primary_tests=24, primary_population="OwnWide Mean, at least50 earlier forecast matches, first strict wick breach; markets kept separate", groups=groups, comparisons=comparisons, sensitivity=sensitivity, limitations=["All history has previously been explored: these are retrospective chronological predictions, not an untouched prospective test.", "Five-minute OHLC cannot resolve same-candle double-break direction or target/return ordering.", "16:00 trigger events remain descriptive only; their EOD close is already known and no future target path remains.", "Each target's pending denominator excludes previously reached and next-open-gap targets; denominators differ by level.", "First-close-outside events are a distinct descriptive population and are not pooled with the first-wick primary model.", "The fixed20-event prior shrinks thin local categories toward the side/type baseline; raw small-cell rates are not deployment recommendations.", "Four forecast methods share dates; alternative-method and all-positive-fit results are exploratory sensitivity, not independent replications.", "No entry, stop, costs, profitability, causality, or live feed has been tested."])
    dump(out / "analysis.json", result)
    dump(out / "descriptive-cells.json", descriptive_cells)
    write_csv(out / "descriptive-tables.csv", descriptive_rows)
    write_csv(out / "walk-forward-predictions.csv", predictions)
    write_csv(out / "annual-comparisons.csv", annual)
    write_csv(out / "sensitivity-comparisons.csv", sensitivity)
    write_csv(out / "calibration-bins.csv", calibration)
    flat = []
    for row in comparisons:
        clean = {k: v for k, v in row.items() if not isinstance(v, (dict, list))}
        for label in ["bootstrap", "late2025"]:
            clean.update({label + "_" + k: v for k, v in row[label].items() if not isinstance(v, (dict, list))})
        for block, stats in row["block_sensitivity"].items():
            clean.update({"block" + block + "_" + k: v for k, v in stats.items()})
        flat.append(clean)
    write_csv(out / "model-comparisons.csv", flat)
    summary = dict(primary_tests=len(comparisons), predictions=len(predictions), descriptive_rows=len(descriptive_rows), sensitivity_tests=len(sensitivity), supported=[{k: r[k] for k in ["market", "outcome", "model", "n", "gain", "relative_brier_reduction", "holm_p", "block5_and20_positive_ci"]} for r in comparisons if r["classification"] == "SUPPORTED"])
    dump(out / "analysis-validation.json", dict(**summary, all24_tests_present=True, same_paired_test_events=True, source_sha256=result["source_sha256"], zero_future_predictors=True, endpoint_eod_excluded=True))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
