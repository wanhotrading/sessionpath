import copy
import datetime as dt
import importlib.util
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location("timing_analysis", Path(__file__).with_name("analyze.py"))
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)


def row(index, date=None, **updates):
    value = dict(eventId=str(index), market="CL", date=date or (dt.date(2022, 1, 1) + dt.timedelta(days=index)).isoformat(), year="2022", contract="TEST", method="nyOwnWide", n=60, eventKind="WICK_FIRST", side="U", type="CLOSE_OUTSIDE", signalCloseMinute=600, timeBlock=600, minutesRemaining=360, closeOvershoot=.15, closeOvershootBin=.1, maxLaterSameSideOvershoot=.5, additionalBeyondSignalExtreme=.35, finalSignedFromOpen=.2, finalSideMultiple=1.1, eodState="SAME_SIDE", targets=[dict(multiple=1.5, triggerReached=False, pending=True, pendingHit=index % 2 == 0)])
    value.update(updates)
    return value


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        self.history = [row(i, timeBlock=600 if i < 10 else 630) for i in range(50)]

    def test_fixed_prior_and_strict_past_prediction(self):
        current = row(99, date="2024-01-02")
        pred, _ = analysis.predictions_for(self.history + [current], "pending150", "time_block")
        self.assertEqual(len(pred), 1)
        self.assertEqual(pred[0]["base_n"], 50)
        self.assertEqual(pred[0]["local_n"], 10)
        self.assertAlmostEqual(pred[0]["p_base"], 26 / 52)
        self.assertAlmostEqual(pred[0]["p_candidate"], (5 + 20 * (26 / 52)) / 30)
        changed = copy.deepcopy(current)
        changed["targets"][0]["pendingHit"] = not current["targets"][0]["pendingHit"]
        altered, _ = analysis.predictions_for(self.history + [changed], "pending150", "time_block")
        self.assertEqual(pred[0]["p_candidate"], altered[0]["p_candidate"])
        self.assertNotEqual(pred[0]["y"], altered[0]["y"])

    def test_multiclass_probabilities_and_endpoint_exclusion(self):
        current = row(99, date="2024-01-02", eodState="INSIDE")
        endpoint = row(100, date="2024-01-03", minutesRemaining=0, signalCloseMinute=960, timeBlock=960)
        pred, excluded = analysis.predictions_for(self.history + [current, endpoint], "eod3", "time_block")
        self.assertEqual(len(pred), 1)
        self.assertEqual(pred[0]["y"], [1, 0, 0])
        self.assertAlmostEqual(sum(pred[0]["p_base"]), 1)
        self.assertAlmostEqual(sum(pred[0]["p_candidate"]), 1)
        self.assertEqual(excluded["eod_already_known_at_endpoint"], 1)

    def test_already_hit_and_wick_inside_are_separate(self):
        already = row(99, date="2024-01-02", targets=[dict(multiple=1.5, triggerReached=True, pending=False, pendingHit=None)])
        pred, excluded = analysis.predictions_for(self.history + [already], "pending150", "time_strength")
        self.assertEqual(pred, [])
        self.assertEqual(excluded["target_not_pending"], 1)
        self.assertEqual(analysis.strength_key(row(100, type="WICK_ONLY", closeOvershootBin=0)), "CLOSED_INSIDE")
        self.assertEqual(analysis.strength_key(row(100, closeOvershootBin=.1)), "10%")

    def test_unscaled_multiclass_brier(self):
        pred = [dict(y=[1, 0, 0], p_base=[.5, .25, .25], p_candidate=[.6, .2, .2], local_n=10)]
        score = analysis.score(pred)
        self.assertAlmostEqual(score["base_brier"], .375)
        self.assertAlmostEqual(score["candidate_brier"], .24)
        self.assertAlmostEqual(score["gain"], .135)
        self.assertEqual(score["sparse_local_fraction"], 1)


if __name__ == "__main__":
    unittest.main()
