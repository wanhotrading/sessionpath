"""Readable offline report and standard scientific figures for NY timing research."""
import sys, json, math, html, hashlib, zipfile, shutil, os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).parent/'mpl-cache'))
sys.path.insert(0, str(Path(__file__).parent / 'python-packages'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

O=Path('outputs/ny-breakout-timing'); W=Path('work/ny-breakout-timing')
A=json.loads((O/'analysis.json').read_text(encoding='utf-8'))
C=json.loads((O/'descriptive-cells.json').read_text(encoding='utf-8'))
X=json.loads((O/'extraction-summary.json').read_text(encoding='utf-8'))
V=json.loads((O/'audit.json').read_text(encoding='utf-8'))
MARKETS=['CL','NQ','ES','GC']; models=['time_block','close_strength','time_strength']
names={'time_block':'Breakout time','close_strength':'Closing overshoot','time_strength':'Time + overshoot'}
pc=lambda v:'—' if v is None else f'{100*v:.1f}%'
num=lambda v:'—' if v is None else f'{v:.4f}'
rate=lambda v: '—' if not v or not v['n'] else f"<b>{pc(v['p'])}</b><small>{v['k']:,}/{v['n']:,} · 95% {pc(v['lo'])}–{pc(v['hi'])}</small>"
E=html.escape
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','svg.fonttype':'none','axes.grid':True,'grid.alpha':.2,'figure.facecolor':'white','axes.facecolor':'white'})
colors={'U':'#c27a19','D':'#7953b8'}
primary=lambda r: r['method']=='nyOwnWide' and r['fit']=='fit50' and r['eventKind']=='WICK_FIRST'
def cell(market, category, side='ALL'):
    return next((r for r in C if primary(r) and r['market']==market and r['group']=='time' and r['category']==category and r['side']==side),None)
def target(r,m=1.5):
    return next((t for t in r['targets'] if abs(t['multiple']-m)<1e-8),None) if r else None
def finish(fig,name):
    fig.savefig(O/(name+'.svg'),bbox_inches='tight')
    fig.savefig(O/(name+'.png'),dpi=150,bbox_inches='tight')
    plt.close(fig)
times=[f'{m//60:02}:{m%60:02}' for m in range(510,960,30)]

fig,axs=plt.subplots(2,2,figsize=(14,9),sharex=True,sharey=True)
for ax,market in zip(axs.flat,MARKETS):
    for side in ['U','D']:
        rs=[cell(market,t,side) for t in times]
        ts=[target(r) for r in rs]
        p=np.array([t['pending_hit']['p'] if t and t['pending_hit']['n'] else np.nan for t in ts],float)
        lo=np.array([t['pending_hit']['lo'] if t and t['pending_hit']['n'] else np.nan for t in ts],float)
        hi=np.array([t['pending_hit']['hi'] if t and t['pending_hit']['n'] else np.nan for t in ts],float)
        xx=np.arange(len(times))+(-.09 if side=='U' else .09)
        ax.errorbar(xx,p,yerr=[np.maximum(0,p-lo),np.maximum(0,hi-p)],fmt='o-',color=colors[side],lw=1.3,markersize=4,capsize=2,label=side+' first')
        for x,y,t in zip(xx,p,ts):
            if t and t['pending_hit']['n'] and t['pending_hit']['n']<20:
                ax.plot(x,y,'o',mfc='white',mec=colors[side],ms=4)
    ax.set_title(market,loc='left');ax.set_ylim(-.03,1.03)
    ax.set_yticks(np.arange(0,1.01,.25),[f'{x}%' for x in [0,25,50,75,100]])
    ax.set_xticks(range(0,len(times),2),times[::2],rotation=40,ha='right')
    ax.legend(loc='upper right',frameon=False,fontsize=9)
fig.suptitle('Later 1.50× target reach by first-breakout confirmation time',fontsize=17,fontweight='bold',y=.995)
fig.text(.01,.012,'Own Wide Mean · ≥50 earlier forecast matches · first strict wick breach · target still pending at confirmation + next open.\n95% Wilson intervals. Hollow markers: fewer than20 pending cases. Descriptive history, not live adjusted forecasts.',fontsize=10)
fig.tight_layout(rect=[0,.07,1,.96]);finish(fig,'pending-150-by-time')

fig,axs=plt.subplots(2,2,figsize=(14,9),sharex=True)
for ax,market in zip(axs.flat,MARKETS):
    for side in ['U','D']:
        rs=[cell(market,t,side) for t in times]
        meds=np.array([r['max_later_multiple']['median'] if r else np.nan for r in rs],float)
        p75=np.array([r['max_later_multiple']['p75'] if r else np.nan for r in rs],float)
        ax.plot(range(len(times)),meds,'o-',color=colors[side],lw=1.7,ms=4,label=side+' median')
        ax.plot(range(len(times)),p75,'--',color=colors[side],lw=1,alpha=.6,label=side+' 75th percentile')
    ax.axhline(1.5,color='#657184',ls=':',lw=1);ax.set_title(market,loc='left')
    ax.set_ylabel('Later maximum range multiple');ax.set_ylim(bottom=.95)
    ax.set_xticks(range(0,len(times),2),times[::2],rotation=40,ha='right')
    ax.legend(frameon=False,fontsize=8,ncol=2)
fig.suptitle('How far later candles travel after the breakout',fontsize=17,fontweight='bold',y=.995)
fig.text(.01,.012,'Full Mean-box width is the ruler.1.50× =50% beyond the breached edge. Subsequent maximum overshoot is floored at zero.\nOwn Wide ≥50-fit first-wick events with later candles; excludes the signal candle. Late groups can be extremely small; see the tables.',fontsize=10)
fig.tight_layout(rect=[0,.07,1,.96]);finish(fig,'later-extension-by-time')

fig,axs=plt.subplots(2,2,figsize=(14,9),sharex=True,sharey=True)
for ax,market in zip(axs.flat,MARKETS):
    rs=[cell(market,t) for t in times]
    total=np.zeros(len(times))
    for state,label,col in [('INSIDE','Inside','#aaa5b8'),('SAME_SIDE','Outside: breakout side','#eead5c'),('OPPOSITE_SIDE','Outside: opposite side','#8555bc')]:
        vals=np.array([r['eod_future_only'][state]['p'] if r and r['eod_future_only'][state]['n'] else np.nan for r in rs],float)
        ax.bar(range(len(times)),vals,bottom=total,color=col,width=.85,label=label)
        total+=np.nan_to_num(vals)
    for i,r in enumerate(rs):
        if r:ax.text(i,1.025,str(r['eod_future_only']['INSIDE']['n']),ha='center',fontsize=7,color='#535d72')
    ax.set_title(market,loc='left',pad=20);ax.set_ylim(0,1.08)
    ax.set_yticks([0,.25,.5,.75,1],['0%','25%','50%','75%','100%'])
    ax.set_xticks(range(0,len(times),2),times[::2],rotation=40,ha='right')
handles,labels=axs[0,0].get_legend_handles_labels()
fig.legend(handles,labels,loc='lower center',ncol=3,bbox_to_anchor=(.5,.035),frameon=False)
fig.suptitle('Where the final 16:00 close ends after a first breakout',fontsize=17,fontweight='bold',y=.995)
fig.text(.01,.006,'Own Wide ≥50-fit first-wick events; U/D combined descriptively. Numbers above bars are event counts.16:00 terminal signals excluded.',fontsize=10)
fig.tight_layout(rect=[0,.085,1,.96]);finish(fig,'eod-close-by-time')

fig,axs=plt.subplots(1,2,figsize=(14,5),sharey=True)
for ax,outcome,title in zip(axs,['pending150','eod3'],['Later pending1.50× target','16:00 closing location']):
    for j,model in enumerate(models):
        rs=[next(r for r in A['comparisons'] if r['market']==m and r['outcome']==outcome and r['model']==model) for m in MARKETS]
        vals=np.array([100*r['relative_brier_reduction'] for r in rs])
        los=np.array([100*r['bootstrap']['lo']/r['base_brier'] for r in rs])
        his=np.array([100*r['bootstrap']['hi']/r['base_brier'] for r in rs])
        yy=np.arange(4)+(j-1)*.23
        ax.errorbar(vals,yy,xerr=[vals-los,his-vals],fmt='o',color=['#7152b5','#ce8628','#3b8b90'][j],ms=5,capsize=3,label=names[model])
    ax.axvline(0,color='#2e3b52',lw=1);ax.set_yticks(range(4),MARKETS);ax.invert_yaxis();ax.set_title(title,loc='left')
    ax.set_xlabel('Relative Brier-error reduction (%) — positive is better')
axs[1].legend(loc='lower right',frameon=False)
fig.suptitle('Do these filters improve later-date forecasts?',fontsize=17,fontweight='bold')
fig.text(.01,.012,'Paired10-date-block bootstrap,3000replicates;95% intervals. Own Wide ≥50-fit;2024+ strictly earlier-date probability fitting.\nNone of24 primary tests passed the fixed support screen. Brier gain is probability-error reduction, not added hit-rate percentage points.',fontsize=10)
fig.tight_layout(rect=[0,.1,1,.92]);finish(fig,'forecast-error-comparison')

def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+E(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'
summ=[]
for m in MARKETS:
    g=next(g for g in A['groups'] if primary(g) and g['market']==m)
    t=target(g)
    summ.append([m,f"{g['events']:,}",f"{g['resolved']:,}",rate(t['pending_hit']),rate(g['eod_future_only']['INSIDE']),rate(g['eod_future_only']['SAME_SIDE']),rate(g['eod_future_only']['OPPOSITE_SIDE'])])
summary=table(['Market','Eligible forecasts','Ordered first breaks','Later1.50× / pending','16:00 inside','16:00 same-side outside','16:00 opposite-side outside'],summ)
scoretables=''
for outcome,title in [('pending150','Pending1.50× extension'),('eod3','Final16:00 closing location')]:
    scoretables+='<h3>'+title+'</h3>'+table(['Market','Added filter','Later test events','Relative Brier reduction','95% relative-gain interval','Local cells with<20 earlier cases','Assessment'],[[r['market'],names[r['model']],r['n'],f"{100*r['relative_brier_reduction']:+.2f}%",f"{100*r['bootstrap']['lo']/r['base_brier']:+.2f}% to {100*r['bootstrap']['hi']/r['base_brier']:+.2f}%",pc(r['sparse_local_fraction']),'Tentative' if r['classification']=='TENTATIVE' else 'No measured improvement'] for r in A['comparisons'] if r['outcome']==outcome])
compact=[]
for r in C:
    compact.append({**{k:r[k] for k in ['market','method','fit','eventKind','group','category','side','resolved','endpoint_only']},'ts':[[t['multiple'],t['pending_hit']['k'],t['pending_hit']['n'],t['trigger_reached']['k'],t['trigger_reached']['n'],t['touched_before_first_close'],t['next_open_gap']] for t in r['targets']], 'eod':[r['eod_future_only'][s]['k'] for s in ['INSIDE','SAME_SIDE','OPPOSITE_SIDE']], 'eodN':r['eod_future_only']['INSIDE']['n'],'later':[r['max_later_multiple'][s] for s in ['mean','median','p75','p90']],'extra':[r['additional_beyond_signal_extreme'][s] for s in ['mean','median','p75']],'final':[r['final_side_multiple'][s] for s in ['mean','median','p75']],'drift':[r['eod_drift_from_signal_close_width'][s] for s in ['mean','median','p75']]})
payload=json.dumps(compact,separators=(',',':'),ensure_ascii=False).replace('</','<\\/')
supported=[r for r in A['comparisons'] if r['classification']=='SUPPORTED']
assert not supported, 'Rewrite the lead if later results change; do not preserve stale conclusions.'
report=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SessionPath NY breakout timing and16:00 close</title><style>
*{box-sizing:border-box}body{margin:0;background:#f3f3f8;color:#202a3f;font:16px/1.65 system-ui,Arial}main{max-width:1250px;margin:auto;padding:30px 26px 70px}h1{font-size:clamp(30px,4vw,47px);line-height:1.13;max-width:1100px}h2{font-size:26px;margin-top:42px}h3{font-size:20px}a{color:#6336a0}p{max-width:1080px}small{display:block;font-size:12px;color:#59677e}nav,.links,.controls{display:flex;gap:15px;flex-wrap:wrap}nav{margin:24px 0}.card,aside{padding:22px;background:white;border:1px solid #d8deea;border-radius:14px;margin:22px 0}.lead{border-left:6px solid #8652ba}.warning{background:#fff6e8;border-left:5px solid #cb8b38}.muted{color:#59677e}.scroll{overflow:auto;max-height:650px;border:1px solid #d9dfec;border-radius:9px;margin:20px 0}table{border-collapse:collapse;width:100%;font-size:13px;font-variant-numeric:tabular-nums}th,td{text-align:left;padding:11px 10px;border-bottom:1px solid #e0e4ee;vertical-align:top}th{background:#e9e5f0;position:sticky;top:0;z-index:1}tr.sparse{background:#faf5eb}tbody tr:hover{background:#f0edf8}.controls label{display:grid;gap:4px;font-size:13px;min-width:130px}.controls select{padding:9px;border:1px solid #b8c2d4;background:white;color:#202a3f;border-radius:7px;max-width:230px}img{display:block;width:100%;height:auto;margin:20px 0;background:white;border:1px solid #d9dfec;border-radius:10px}code{background:#e6e9f2;padding:2px 4px}summary{cursor:pointer;font-weight:650}details{margin:24px 0}.metrics{font-size:14px;padding:14px;border-radius:9px;background:#eae7f3;margin:15px 0}.fine{font-size:13px}button{border:0;border-radius:7px;padding:10px 15px;background:#6941a1;color:white;cursor:pointer}@media(max-width:650px){main{padding:20px 15px}.controls label{flex:1;min-width:130px}.controls select{max-width:100%}th,td{padding:9px 7px}h2{font-size:23px}}@media print{body{background:white}main{max-width:none;padding:0}nav,.controls,button{display:none}.scroll{max-height:none;overflow:visible}th{position:static}aside,img{break-inside:avoid}h2{break-after:avoid}table{font-size:9px}.card{padding:10px}img{max-height:520px;object-fit:contain}}
</style></head><body><main><p class="muted">SESSIONPATH RESEARCH · WAN HO.LUI ·2 NOVEMBER2026</p><h1>When NY breaks the box: timing, further extension and the16:00 close</h1><p>CL · NQ · ES · Gold. Ordinary Mean SessionPath08:30–16:00 boxes, unchanged. First-wick and first-close-outside events are measured separately.</p><nav><a href="../../">SessionPath</a><a href="#findings">Findings</a><a href="#inspect">Inspect the time groups</a><a href="#scores">Forecast tests</a><a href="#method">Definitions</a><a href="#downloads">Download data</a></nav>
<aside class="lead"><b>Timing describes different paths, but this study has not established a reliable upgrade to the live1.50× forecast.</b><p>Of24 fixed tests of time, closing overshoot and their combination, none passed the full support screen. Timing slightly reduced pending1.50× probability error in CL, NQ and ES; it increased error in gold. Every timing confidence interval crossed zero. Timing did not establish improved forecasting of the16:00 close.</p><p>The live indicator’s percentage lookup and forecast widths have not been changed. This page adds the measured timing/extension/EOD evidence for review.</p></aside>
<h2 id="findings">What was measured</h2><p>Primary view: Own Wide Mean forecasts fitted on at least50 earlier matched dates. These figures describe the full eligible research history. Later-date forecast scores use smaller samples after the required50-event probability-model warmup.</p>__SUMMARY__
<aside class="warning"><b>Late breakout groups are thin.</b> Among evaluated timing predictions, the exact side/type/time group had fewer than20 earlier cases in95.4% of CL predictions,86.9% of NQ,99.2% of ES and93.0% of gold. The test therefore shrinks each time group toward its broader side/type baseline. A raw late-day percentage should not be read as a precise live estimate.</aside>
<p><b>A target touch and an outside final close answer different questions.</b> A day can reach1.50×, reverse, and finish inside the original box. The target table and final-close table preserve those outcomes separately.</p>
<img src="pending-150-by-time.svg" alt="Separate upward and downward pending1.50x target rates by half-hour confirmation block with95percent intervals"><img src="later-extension-by-time.svg" alt="Median and75th percentile of later maximum extension by confirmation block, separate upward and downward"><img src="eod-close-by-time.svg" alt="Final16:00 close inside, same-side outside or opposite-side outside by confirmation block with sample counts">
<h2 id="inspect">Inspect breakout time and candle size</h2><p>The table uses completed-candle confirmation time. A candle opening09:25 confirms09:30 and belongs to09:30–09:59. The final15:55 candle confirms16:00 and has no future period. “First close outside” may occur later than the first wick breach; choose the event definition you actually observed.</p>
<form id="filters" class="controls"><label>Market<select id="market"><option>CL</option><option>NQ</option><option>ES</option><option>GC</option></select></label><label>NY box method<select id="method"><option value="nyOwnWide">Own Wide Mean</option><option value="nyOwnExact">Own Exact Mean</option><option value="nyPriorWide">Prior Wide Mean</option><option value="nyPriorExact">Prior Exact Mean</option></select></label><label>Earlier box matches<select id="fit"><option value="fit50">At least50 · primary</option><option value="all_positive_fit">At least1 · sensitivity</option></select></label><label>Observed event<select id="eventKind"><option value="WICK_FIRST">First strict wick breach</option><option value="CLOSE_FIRST">First close outside</option></select></label><label>Breakout side<select id="side"><option value="ALL">Both sides · descriptive</option><option value="U">U · upper first</option><option value="D">D · lower first</option></select></label><label>Target multiple<select id="level"><option>1.20</option><option>1.30</option><option>1.40</option><option selected>1.50</option><option>1.75</option><option>2.00</option></select></label></form>
<p class="metrics" id="status" role="status" aria-live="polite"></p><p class="fine">Shaded rows have fewer than20 pending cases for the selected target. Rates show hits/cases and95% Wilson intervals. “Pending” excludes any earlier/trigger target touch and a next open already at the target. A zero denominator is unavailable, never0%.</p>
<h3>Time and later extension</h3><div class="scroll"><table><thead><tr><th>Confirmation block NY</th><th>First breaks</th><th>Target hit on signal candle</th><th>Later target / pending cases</th><th>Later maximum: mean / median /75th</th><th>Added beyond signal extreme: median</th></tr></thead><tbody id="time-table"></tbody></table></div>
<p class="fine">Later maximum uses only candles after the signal and floors boundary overshoot at zero:1.00 means no further move beyond that boundary. Added beyond the signal extreme includes zero and is expressed as% of total Mean-box width. The table is a historical description; current time does not turn it into a live remaining-time forecast.</p>
<h3>Where the16:00 close finished</h3><div class="scroll"><table><thead><tr><th>Confirmation block NY</th><th>Final close inside</th><th>Outside on breakout side</th><th>Outside opposite side</th><th>Median final position</th><th>Median drift after signal close</th></tr></thead><tbody id="eod-table"></tbody></table></div><p class="fine">EOD rates exclude terminal16:00 signals. For final position,1.00 is the breached boundary and0.00 is the opposite boundary; values between0 and1 are inside. Drift is side-aligned: positive means movement in the breakout direction. EOD is this study’s16:00 cutoff, not an exchange settlement price.</p>
<h3>Closing overshoot groups</h3><p>Closing overshoot uses the completed close, not the candle’s furthest wick. A close14% of full width outside is placed in10–&lt;20%; a close27% outside is placed in20–&lt;30%. A wick breach closing inside is its own group.</p><div class="scroll"><table><thead><tr><th>Closing overshoot / full width</th><th>Events</th><th>Later target / pending cases</th><th>EOD inside</th><th>EOD same-side outside</th><th>Median later maximum</th></tr></thead><tbody id="strength-table"></tbody></table></div>
<h2 id="scores">Did conditioning improve later-date forecasts?</h2><p>Each candidate is compared with the same baseline, on the same later test events. The baseline already distinguishes U/D and wick-only/close-outside. All probability fitting uses strictly earlier dates. Added filters are assessed individually, then together, with fixed20-case shrinkage toward the baseline.</p><img src="forecast-error-comparison.svg" alt="Later-date Brier error reductions and95percent uncertainty intervals for24 prespecified timing and overshoot comparisons">__SCORES__
<p>A positive relative Brier reduction means less squared probability error. It is not extra percentage points added to a hit rate. None of the24 tests passed the fixed combined requirements for uncertainty, multiple testing and yearly consistency. This does not prove time has no influence; the evidence is insufficient to treat these particular adjusted rates as a proven upgrade.</p>
<details><summary>Why the forecast-test sample is smaller</summary><p>The full descriptive history includes every eligible first break with at least50 earlier dates fitting its original box. A probability prediction additionally needs50 strictly earlier outcome-eligible events with the same side and wick/close type, and evaluation begins2024. That leaves237 CL,222 NQ,252 ES and214 GC pending1.50× test events. The broader “at least1” and other-method sensitivities are saved separately; they are not independent confirmations because their dates overlap.</p></details>
<h2 id="method">Definitions and safeguards</h2><div class="card"><p><b>Range ruler:</b> W=H−L. Upward target=L+mW; downward=H−mW. For an89–91 box,1.50× is92.00 upward or88.00 downward. It is50% beyond the boundary.</p><p><b>First wick breach:</b> strict high above H or low below L. Equality is not a breach. If both first breaches occur in the same candle, first direction is unknown and is excluded from side-dependent analysis. First close outside is a separate alternative population.</p><p><b>Pending target:</b> target untouched on every candle through the signal and also untouched at the next opening price, with at least one later candle. Only later wick touches count as future hits. For first-close-outside events, an earlier wick may already have reached the target.</p><p><b>Final close:</b> close of the15:55–16:00 candle. The16:00 opening candle is excluded. Terminal16:00 observations are retained in the ledger but excluded from future predictions.</p><p><b>Earlier-only boxes:</b> historical Mean widths were reconstructed from their saved cohorts, all strictly before each forecast date. No box was widened or narrowed for this test. Sources use explicit delivery contracts and the existing frozen ten-day AVR conventions.</p><p><b>Testing:</b> Own Wide≥50-fit first-wick events are primary. Probability evaluation begins2024 with50 earlier side/type outcome events. Binary Brier=(p−y)². Three-state EOD Brier sums three squared errors on its0–2 scale; do not compare its level directly with the binary score. Paired10-date-block bootstrap uses3000 replicates, with5/20-date sensitivities and a24-test Holm adjustment. Full fixed rules are in the protocol.</p><p><b>Limits:</b> this history was explored in earlier studies, so this is a retrospective chronological test, not an untouched prospective holdout. Five-minute OHLC cannot resolve all intrabar ordering. Time groups can also reflect volatility/news regimes; the study does not establish causation, entries, stops, transaction costs or profitability.</p><p class="fine">Method references: <a href="https://scikit-learn.org/stable/modules/generated/sklearn.metrics.brier_score_loss.html">Brier score definition</a> · <a href="https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html">Chronological evaluation and future-data leakage</a>.</p></div>
<h2 id="downloads">Collected data and reproducibility</h2><p>36,396 event records and218,376 target records are saved. These include four overlapping forecast methods and two alternative event definitions; they are not36,396 independent trading days. CL/NQ source period:2022-01-03 through2026-10-15. ES/GC:2022-01-03 through2026-10-20.</p><div class="links"><a href="SessionPath-NY-breakout-timing-data.zip">Download study data and calculation code ZIP</a><a href="model-comparisons.csv">Forecast-test results CSV</a><a href="annual-comparisons.csv">Yearly tests CSV</a><a href="sensitivity-comparisons.csv">Other methods and sample sensitivity CSV</a><a href="protocol.txt">Fixed protocol</a><a href="data-dictionary.json">Data dictionary</a><a href="audit.json">Independent extraction checks</a></div><p>Independent verification recalculated every event and target, checked source-native final candles on eight dates, and exercised boundary, ambiguous, already-hit and terminal cases. Source hashes and exclusions are included in the download.</p><button type="button" onclick="window.print()">Print / save PDF</button><p class="muted fine">Research reference only. Existing live indicator percentage lookup unchanged in this release.</p></main>
<script id="cells" type="application/json">__PAYLOAD__</script><script>
const cells=JSON.parse(document.getElementById('cells').textContent),$=id=>document.getElementById(id),ids=['market','method','fit','eventKind','side'];
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pct=v=>Number.isFinite(v)?(100*v).toFixed(1)+'%':'—',mult=v=>Number.isFinite(v)?v.toFixed(2)+'×':'—';
function rate(k,n){if(!n)return '—';let p=k/n,z=1.95996398454,a=1+z*z/n,c=(p+z*z/(2*n))/a,e=z*Math.sqrt(p*(1-p)/n+z*z/(4*n*n))/a;return '<b>'+pct(p)+'</b><small>'+k+'/'+n+' ·95% '+pct(Math.max(0,c-e))+'–'+pct(Math.min(1,c+e))+'</small>';}
function render(){let f=Object.fromEntries(ids.map(k=>[k,$(k).value])),level=Number($('level').value);let rs=cells.filter(r=>ids.every(k=>r[k]===f[k])),times=rs.filter(r=>r.group==='time').sort((a,b)=>a.category.localeCompare(b.category));let strengths=rs.filter(r=>r.group==='strength').sort((a,b)=>a.category==='CLOSED_INSIDE'?-1:b.category==='CLOSED_INSIDE'?1:parseInt(a.category)-parseInt(b.category));let tar=r=>r.ts.find(t=>Math.abs(t[0]-level)<1e-6);let label=r=>r.category==='16:00_ENDPOINT_ONLY'?'16:00 · no later candles':r.category+'–'+r.category.slice(0,3)+(Number(r.category.slice(3))+29).toString().padStart(2,'0');
$('status').textContent=f.market+' · '+$('method').selectedOptions[0].text+' · '+$('eventKind').selectedOptions[0].text+' · '+$('side').selectedOptions[0].text+' · '+level.toFixed(2)+'× target. These are descriptive historical groups.';
$('time-table').innerHTML=times.map(r=>{let t=tar(r);return '<tr class="'+(t&&t[2]<20?'sparse':'')+'"><td>'+label(r)+'</td><td>'+r.resolved+'</td><td>'+rate(t?.[3],t?.[4])+'</td><td>'+rate(t?.[1],t?.[2])+'</td><td>'+r.later.slice(0,3).map(mult).join(' / ')+'</td><td>'+pct(r.extra[1])+' of W</td></tr>'}).join('')||'<tr><td colspan="6">No eligible data.</td></tr>';
$('eod-table').innerHTML=times.map(r=>'<tr class="'+(r.eodN<20?'sparse':'')+'"><td>'+label(r)+'</td>'+r.eod.map(k=>'<td>'+rate(k,r.eodN)+'</td>').join('')+'<td>'+mult(r.final[1])+'</td><td>'+pct(r.drift[1])+' of W</td></tr>').join('');
$('strength-table').innerHTML=strengths.map(r=>{let t=tar(r),s=r.category==='CLOSED_INSIDE'?'Wick-only · closed inside':parseInt(r.category)+'–<'+(parseInt(r.category)+10)+'%';return '<tr class="'+(t&&t[2]<20?'sparse':'')+'"><td>'+s+'</td><td>'+r.resolved+'</td><td>'+rate(t?.[1],t?.[2])+'</td><td>'+rate(r.eod[0],r.eodN)+'</td><td>'+rate(r.eod[1],r.eodN)+'</td><td>'+mult(r.later[1])+'</td></tr>'}).join('');
let q=new URLSearchParams(f);q.set('level',level.toFixed(2));history.replaceState(null,'','?'+q+location.hash);}
let params=new URLSearchParams(location.search);for(let id of [...ids,'level']){let v=params.get(id)||(id==='market'?params.get('instrument'):null);if(v&&[...$(id).options].some(o=>o.value===v))$(id).value=v;}
$('filters').addEventListener('change',render);$('filters').addEventListener('submit',e=>e.preventDefault());render();
</script></body></html>'''
report=report.replace('__SUMMARY__',summary).replace('__SCORES__',scoretables).replace('__PAYLOAD__',payload)
report=report.replace('and16:00 close</title>','and 16:00 close</title>')
report=report.replace('href="#method"','href="#methodology"').replace('<h2 id="method">','<h2 id="methodology">')
report=report.replace('The baseline already distinguishes U/D and wick-only/close-outside.', 'The baseline already distinguishes U/D and wick-only/close-outside. This isolates the extra contribution of time and closing distance; it is not a direct score of every custom NY forecast produced by the live site.')
# Add natural spacing to prose only; never alter CSS, tag names, IDs or data.
import re
head,body=report.split('<body>',1)
prose,script=body.split('<script id="cells"',1)
chunks=re.split(r'(<[^>]*>)',prose)
for i,chunk in enumerate(chunks):
    if not chunk.startswith('<'):
        chunks[i]=re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=(?!st\b|nd\b|rd\b|th\b)[A-Za-z])',' ',chunk)
report=head+'<body>'+''.join(chunks)+'<script id="cells"'+script
(O/'SessionPath-NY-breakout-timing.html').write_text(report,encoding='utf-8')
shutil.copyfile(W/'protocol.txt',O/'protocol.txt')
files=['events.csv','targets.csv','descriptive-tables.csv','model-comparisons.csv','annual-comparisons.csv','sensitivity-comparisons.csv','calibration-bins.csv','walk-forward-predictions.csv','analysis.json','analysis-validation.json','analysis-audit.json','analysis-summary.txt','audit.json','source-files.json','raw-source-provenance.json','extraction-summary.json','config.json','schema.json','data-dictionary.json','calendar.json','protocol.txt']
if (O/'statistical-audit.json').exists():files.append('statistical-audit.json')
with zipfile.ZipFile(O/'SessionPath-NY-breakout-timing-data.zip','w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for name in files:z.write(O/name,name)
    for name in ['core.mjs','core.test.mjs','extract.mjs','finalize-calendar.mjs','analyze.py','test_analysis.py','audit_analysis.py','audit.mjs','statistical-audit.py','report.py','check-report.mjs']:
        if (W/name).exists():z.write(W/name,'calculation-code/'+name)
    for p in O.glob('*-fit-audit.json'):z.write(p,p.name)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in O.iterdir() if p.is_file() and p.suffix not in ['.jsonl']}
(O/'report-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({'report_bytes':(O/'SessionPath-NY-breakout-timing.html').stat().st_size,'zip_bytes':(O/'SessionPath-NY-breakout-timing-data.zip').stat().st_size,'cells':len(compact),'figures':4,'supported':len(supported)}))
