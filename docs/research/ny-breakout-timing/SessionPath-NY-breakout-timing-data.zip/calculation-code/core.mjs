import {EPS} from '../ny-sessionpath-extension-core.mjs';
export const LEVELS=[1.2,1.3,1.4,1.5,1.75,2];
export const OPEN=510, END=960;
export const minuteText=n=>n==null?null:`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
// Snap only arithmetic residue at exact tenths; never round 14% into the 20% bin.
export function floorTenth(x){const y=Math.max(0,x)*10,r=Math.round(y);return Math.floor(Math.abs(y-r)<1e-10?r:y)/10;}
const within=(p,l,u)=>p>=l-EPS&&p<=u+EPS;
const sideAt=(p,l,u)=>p>u+EPS?'U':p<l-EPS?'D':null;
const signed=(p,side,l,u,w)=>side==='U'?(p-u)/w:(l-p)/w;
const first=(bars,fn)=>bars.findIndex(fn);
const barMinute=i=>i<0?null:OPEN+5*i;
const touched=(b,side,target)=>side==='U'?b.high>=target-EPS:b.low<=target+EPS;
const openedAt=(b,side,target)=>side==='U'?b.open>=target-EPS:b.open<=target+EPS;

export function scoreEvents(observation,extra={}){
 const {future:bars,upper,lower,width,open}=observation;
 if(bars.length!==90)throw Error('Expected exactly 90 five-minute bars');
 const u=first(bars,b=>b.high>upper+EPS),d=first(bars,b=>b.low<lower-EPS);
 const wi=u<0?d:d<0?u:Math.min(u,d);
 const ws=wi<0?'NONE':u===d?'AMBIGUOUS':u===wi?'U':'D';
 const ci=first(bars,b=>sideAt(b.close,lower,upper));
 const cs=ci<0?'NONE':sideAt(bars[ci].close,lower,upper);
 const {future:_,...base}=observation;
 const eodClose=bars.at(-1).close,eodBoxState=within(eodClose,lower,upper)?'INSIDE':eodClose>upper?'ABOVE':'BELOW';
 return [['WICK_FIRST',wi,ws],['CLOSE_FIRST',ci,cs]].map(([eventKind,i,side])=>{
  const resolved=side==='U'||side==='D',trigger=i<0?null:bars[i],next=i<0?null:bars[i+1],later=i<0?[]:bars.slice(i+1);
  const signalOpenMinute=barMinute(i),signalCloseMinute=signalOpenMinute==null?null:signalOpenMinute+5;
  const sideExtreme=resolved?(side==='U'?trigger.high:trigger.low):null;
  const wickOvershoot=resolved?signed(sideExtreme,side,lower,upper,width):null;
  const closeOvershoot=resolved?signed(trigger.close,side,lower,upper,width):null;
  const laterExtreme=resolved&&later.length?(side==='U'?Math.max(...later.map(b=>b.high)):Math.min(...later.map(b=>b.low))):null;
  const finalSignedFromOpen=resolved?(side==='U'?eodClose-open:open-eodClose)/width:null;
  const record={...base,...extra,eventId:[extra.market,observation.date,observation.method,eventKind].join('|'),eventKind,side,
   type:!resolved?(side==='NONE'?'NO_BREAK':'AMBIGUOUS'):sideAt(trigger.close,lower,upper)===side?'CLOSE_OUTSIDE':'WICK_ONLY',
   firstWickSide:ws,firstWickOpenMinute:barMinute(wi),firstCloseSide:cs,firstCloseOpenMinute:barMinute(ci),
   signalOpenMinute,signalCloseMinute,signalOpenTime:minuteText(signalOpenMinute),signalCloseTime:minuteText(signalCloseMinute),
   timeBlock:signalCloseMinute==null?null:Math.floor(signalCloseMinute/30)*30,
   timeBlockLabel:signalCloseMinute==null?null:signalCloseMinute===END?'16:00 terminal':`${minuteText(Math.floor(signalCloseMinute/30)*30)}–${minuteText(Math.floor(signalCloseMinute/30)*30+29)}`,
   minutesRemaining:signalCloseMinute==null?null:END-signalCloseMinute,signalIndex:i,
   signalOpen:trigger?.open??null,signalHigh:trigger?.high??null,signalLow:trigger?.low??null,signalClose:trigger?.close??null,nextOpen:next?.open??null,
   wickOvershoot,closeOvershoot,wickOvershootBin:resolved?floorTenth(wickOvershoot):null,closeOvershootBin:resolved?floorTenth(closeOvershoot):null,
   firstCloseAfterWickMinutes:wi>=0&&ci>=0?(ci-wi)*5:null,
   eodClose,eodCloseKnownMinute:END,eodBoxState,
   eodState:resolved?(eodBoxState==='INSIDE'?'INSIDE':(side==='U'?eodBoxState==='ABOVE':eodBoxState==='BELOW')?'SAME_SIDE':'OPPOSITE_SIDE'):null,
   finalSignedFromOpen,finalSideMultiple:resolved?1+signed(eodClose,side,lower,upper,width):null,
   finalOutsideDistance:resolved?signed(eodClose,side,lower,upper,width):null,
   maxLaterSameSideOvershoot:resolved?Math.max(0,laterExtreme==null?0:signed(laterExtreme,side,lower,upper,width)):null,
   maxLaterSameSideMultiple:resolved&&laterExtreme!=null?1+signed(laterExtreme,side,lower,upper,width):null,
   maxSessionSameSideOvershoot:resolved?Math.max(0,...bars.map(b=>signed(side==='U'?b.high:b.low,side,lower,upper,width))):null,
   additionalBeyondSignalExtreme:resolved?Math.max(0,laterExtreme==null?0:(side==='U'?laterExtreme-sideExtreme:sideExtreme-laterExtreme)/width):null,
   laterBars:later.length,targets:[]};
  record.targets=LEVELS.map(multiple=>{
   const target=resolved?(side==='U'?lower+multiple*width:upper-multiple*width):null;
   const triggerReached=resolved?touched(trigger,side,target):null;
   const beforeSignal=resolved&&i>0?bars.slice(0,i).some(b=>touched(b,side,target)):false;
   const touchedThroughSignal=resolved?(beforeSignal||triggerReached):null;
   const nextOpenGap=resolved&&!!next&&!touchedThroughSignal&&openedAt(next,side,target);
   const noRemaining=resolved&&!next;
   const pending=resolved&&!touchedThroughSignal&&!nextOpenGap&&!!next;
   const li=resolved?first(later,b=>touched(b,side,target)):-1;
   const absoluteLater=li<0?-1:i+1+li;
   const hitOpen=barMinute(absoluteLater);
   return {multiple,target,triggerReached,touchedBeforeSignal:resolved?beforeSignal:null,
    touchedBeforeFirstClose:eventKind==='CLOSE_FIRST'?beforeSignal:null,touchedThroughSignal,
    nextOpenGap,noRemaining,pending,laterHit:resolved?li>=0:null,pendingHit:pending?(li>=0):null,
    laterHitOpenMinute:hitOpen,laterHitCloseMinute:hitOpen==null?null:hitOpen+5,
    firstTargetHitOpenMinute:resolved?barMinute(first(bars,b=>touched(b,side,target))):null};
  });
  return record;
 });
}
