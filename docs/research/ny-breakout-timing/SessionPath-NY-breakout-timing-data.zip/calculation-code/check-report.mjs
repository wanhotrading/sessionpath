import fs from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const html=await fs.readFile('outputs/ny-breakout-timing/SessionPath-NY-breakout-timing.html','utf8');
assert(html.includes('<h1>'));assert(!html.includes('<h 1>'));
const data=html.match(/<script id="cells" type="application\/json">([\s\S]*?)<\/script>/)[1];
const code=html.match(/<\/script><script>([\s\S]*?)<\/script>/)[1];
const vals={market:['CL','NQ','ES','GC'],method:['nyOwnWide','nyOwnExact','nyPriorWide','nyPriorExact'],fit:['fit50','all_positive_fit'],eventKind:['WICK_FIRST','CLOSE_FIRST'],side:['ALL','U','D'],level:['1.20','1.30','1.40','1.50','1.75','2.00']};
const els=Object.fromEntries(Object.entries(vals).map(([id,options])=>[id,{value:id==='level'?'1.50':options[0],options:options.map(value=>({value})),get selectedOptions(){return[{text:this.value}]}}]));
for(const id of ['status','time-table','eod-table','strength-table'])els[id]={};
els.cells={textContent:data};els.filters={addEventListener(){}};
let nextURL='';
const context=vm.createContext({document:{getElementById:id=>els[id]},URLSearchParams,location:{search:'',hash:''},history:{replaceState(a,b,s){nextURL=s}}});
vm.runInContext(code,context);
assert(els['time-table'].innerHTML.includes('09:00–09:29'));
assert(els['time-table'].innerHTML.includes('25/56'));
assert(els['eod-table'].innerHTML.includes('16:00 · no later candles'));
assert(nextURL.includes('level=1.50'));
let checks=4;
for(const market of vals.market)for(const method of vals.method)for(const fit of vals.fit)for(const eventKind of vals.eventKind)for(const side of vals.side)for(const level of vals.level){
 for(const[k,v]of Object.entries({market,method,fit,eventKind,side,level}))els[k].value=v;
 vm.runInContext('render()',context);
 for(const id of ['time-table','eod-table','strength-table']){
  assert(els[id].innerHTML.includes('<tr'));assert(!els[id].innerHTML.includes('NaN'));assert(!els[id].innerHTML.includes('undefined'));checks+=3;
 }
 assert(els.status.textContent.includes(market));checks++;
 assert(nextURL.includes('level='+level));checks++;
}
const cells=JSON.parse(data);for(const c of cells){assert.equal(c.eod.reduce((a,b)=>a+b,0),c.eodN);checks++;}
await fs.writeFile('outputs/ny-breakout-timing/report-validation.json',JSON.stringify({status:'PASS',checks,cells:cells.length,allFilterCombinations:1152,knownCL0900:'25/56',queryPreservesDecimals:true,terminalAvailableNotFuture:true,reportBytes:Buffer.byteLength(html)},null,2));
console.log(JSON.stringify({checks,cells:cells.length,status:'PASS'}));
