import test from 'node:test';
import assert from 'node:assert/strict';
import {scoreEvents,floorTenth} from './core.mjs';
const blank=()=>Array.from({length:90},()=>({open:90,high:90.5,low:89.5,close:90}));
const score=bars=>scoreEvents({date:'2026-10-20',year:'2026',contract:'CLZ2026',method:'nyOwnWide',n:50,avr:2,open:90,meanUp:1,meanDown:1,upper:91,lower:89,width:2,future:bars},{market:'CL'});
test('1.5 target is50% beyond full-width boundary;triggerhit excludespending',()=>{
 const b=blank();b[0]={open:90,high:92,low:89.5,close:91.2};const w=score(b)[0];
 assert.equal(w.targets[3].target,92);assert.equal(w.targets[3].triggerReached,true);assert.equal(w.targets[3].pending,false);assert.equal(w.signalCloseMinute,515);
});
test('prior wick target touch excludes pending atfirstclose outside',()=>{
 const b=blank();b[0]={open:90,high:92.2,low:89.5,close:90};b[2]={open:90,high:91.4,low:90,close:91.3};
 const [w,c]=score(b);assert.equal(w.type,'WICK_ONLY');assert.equal(c.side,'U');assert.equal(c.targets[3].touchedBeforeFirstClose,true);assert.equal(c.targets[3].triggerReached,false);assert.equal(c.targets[3].pending,false);
});
test('same-bar two-sided first wick ambiguous; firstclose separately identified',()=>{
 const b=blank();b[0]={open:90,high:91.2,low:88.8,close:90};b[1]={open:90,high:91.2,low:90,close:91.1};
 const [w,c]=score(b);assert.equal(w.side,'AMBIGUOUS');assert(w.targets.every(t=>!t.pending));assert.equal(c.side,'U');assert.equal(c.signalCloseMinute,520);
});
test('next opening target gap excluded frompending thoughpostsignal touch retained',()=>{
 const b=blank();b[0]={open:90,high:91.1,low:89.5,close:91.05};b[1]={open:92,high:92.1,low:91.5,close:92};
 const w=score(b)[0];assert.equal(w.targets[3].nextOpenGap,true);assert.equal(w.targets[3].pending,false);assert.equal(w.targets[3].laterHit,true);
});
test('15:55 signal confirms16:00, usesfinalclose, andhas nofuture opportunity',()=>{
 const b=blank();b[89]={open:90,high:91.2,low:90,close:91.1};const w=score(b)[0];
 assert.equal(w.signalOpenMinute,955);assert.equal(w.signalCloseMinute,960);assert.equal(w.timeBlock,960);assert.equal(w.minutesRemaining,0);assert.equal(w.eodClose,91.1);assert.equal(w.eodState,'SAME_SIDE');assert.equal(w.additionalBeyondSignalExtreme,0);assert(w.targets.every(t=>t.noRemaining&&!t.pending));
});
test('completed-timebins andtenths do notroundup',()=>{
 const b=blank();b[5]={open:90,high:91.3,low:90,close:91.28};const w=score(b)[0];
 assert.equal(w.signalOpenMinute,535);assert.equal(w.signalCloseMinute,540);assert.equal(w.timeBlock,540);assert.equal(w.closeOvershootBin,.1);assert.equal(floorTenth(.27),.2);assert.equal(floorTenth(.1-1e-15),.1);assert.equal(floorTenth(.0999999),0);
});
test('laterHLCcannotchange observed features, andnextopen solelychangesentrygate',()=>{
 const b=blank();b[2]={open:90,high:91.2,low:90,close:91.1};const before=score(b)[0];
 const changed=structuredClone(b);changed[20]={open:90,high:94,low:88,close:93};const after=score(changed)[0];
 for(const k of ['signalIndex','side','type','signalCloseMinute','timeBlock','wickOvershoot','closeOvershoot','closeOvershootBin','upper','lower','width'])assert.equal(before[k],after[k]);
 assert.equal(before.targets[3].pending,after.targets[3].pending);assert.equal(before.targets[3].pendingHit,false);assert.equal(after.targets[3].pendingHit,true);
});
test('lower side mirrors upper; EOD equality belongsinside',()=>{
 const b=blank();b[0]={open:90,high:90,low:88.8,close:88.9};b[3]={open:88.5,high:89,low:88,close:88.2};b[89]={open:89,high:89,low:88.9,close:89};
 const w=score(b)[0];assert.equal(w.side,'D');assert.equal(w.targets[3].target,88);assert.equal(w.targets[3].pendingHit,true);assert.equal(w.eodState,'INSIDE');assert.equal(w.finalOutsideDistance,0);assert(Math.abs(w.additionalBeyondSignalExtreme-.4)<1e-12);
});
