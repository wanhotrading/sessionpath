import fs from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import readline from 'node:readline';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';

// Independent recalculation. Deliberately does not import the study extractor/core.
const OUT='outputs/ny-breakout-timing', EPS=1e-9, LEVELS=[1.2,1.3,1.4,1.5,1.75,2];
const json=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const normalized=await json('outputs/first-breach-study/normalized-sources.json');
const data={CL:normalized.CL,NQ:normalized.NQ,ES:await json('outputs/es-model/research-days.json'),GC:await json('outputs/gc-model/research-days.json')};
for(const m of ['CL','NQ']) data[m]=data[m].map(d=>({...d,bars:d.bars.map(b=>b?Object.fromEntries(['open','high','low','close'].map((k,i)=>[k,b[i]])):null)}));
const forecasts={};
for(const [m,p]of Object.entries({CL:'outputs/orange-box-fill/CL-clean-forecasts.json',NQ:'outputs/orange-box-fill/NQ-clean-forecasts.json',ES:'outputs/es-orange-box-fill/ES-clean-forecasts.json',GC:'outputs/gc-orange-box-fill/GC-clean-forecasts.json'}))forecasts[m]=new Map((await json(p)).map(r=>[r.date+'|'+r.variant,r]));
const days=Object.fromEntries(Object.entries(data).map(([m,a])=>[m,new Map(a.map(d=>[d.date,d]))]));
const result={status:'RUNNING',independent:true,extractorImported:false,checks:0,eventRows:0,targetRows:0,marketEvents:{},edgeCounts:{},samples:[],nativeCSVParity:[],files:{}};
const fail=(message,details)=>{const e=new Error(message+' '+JSON.stringify(details));throw e;};
const equal=(actual,expected,field,id)=>{result.checks++;if(typeof expected==='number'){if(!(typeof actual==='number'&&Math.abs(actual-expected)<=1e-8))fail('Numeric mismatch',{id,field,actual,expected});}else if(actual!==expected)fail('Value mismatch',{id,field,actual,expected});};
const six=x=>Number(x.toFixed(6));
const sideOf=(p,l,u)=>p>u+EPS?'U':p<l-EPS?'D':null;
const tenth=x=>{const y=Math.max(0,x)*10,r=Math.round(y);return Math.floor(Math.abs(y-r)<1e-10?r:y)/10;};
const mt=n=>n==null?null:`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
const expectations=new Map(),sampleCandidates=new Map();
for await(const line of readline.createInterface({input:createReadStream(OUT+'/events.jsonl'),crlfDelay:Infinity})){
 if(!line)continue;
 const e=JSON.parse(line),id=e.eventId,d=days[e.market]?.get(e.date),f=forecasts[e.market]?.get(e.date+'|'+e.method);
 assert(d&&f,'Missing source '+id);assert.equal(f.mode,'earlier-only');assert(f.cohortDates.every(x=>x<e.date));
 const b=d.bars.slice(156,246);assert.equal(b.length,90);assert(b.every(x=>x&&['open','high','low','close'].every(k=>Number.isFinite(x[k]))));
 const open=six(b[0].open),u=open+six(f.meanUp),l=open-six(f.meanDown),w=u-l;
 const ui=b.findIndex(x=>x.high>u+EPS),di=b.findIndex(x=>x.low<l-EPS),wi=ui<0?di:di<0?ui:Math.min(ui,di),ws=wi<0?'NONE':ui===di?'AMBIGUOUS':wi===ui?'U':'D';
 const ci=b.findIndex(x=>sideOf(x.close,l,u)),cs=ci<0?'NONE':sideOf(b[ci].close,l,u);
 const i=e.eventKind==='WICK_FIRST'?wi:ci,s=e.eventKind==='WICK_FIRST'?ws:cs,resolved=s==='U'||s==='D',signal=i<0?null:b[i],later=i<0?[]:b.slice(i+1),next=i<0?null:b[i+1];
 const minute=i<0?null:510+5*i,closeMinute=minute==null?null:minute+5,block=closeMinute==null?null:Math.floor(closeMinute/30)*30;
 const aligned=p=>s==='U'?(p-u)/w:(l-p)/w;
 const extreme=resolved?(s==='U'?signal.high:signal.low):null,lateExtreme=resolved&&later.length?(s==='U'?Math.max(...later.map(x=>x.high)):Math.min(...later.map(x=>x.low))):null;
 const end=b[89].close,boxState=sideOf(end,l,u)==null?'INSIDE':end>u?'ABOVE':'BELOW';
 const expected={contract:d.contract,n:f.cases,avr:d.avr,open,meanUp:six(f.meanUp),meanDown:six(f.meanDown),upper:u,lower:l,width:w,side:s,type:resolved?(sideOf(signal.close,l,u)===s?'CLOSE_OUTSIDE':'WICK_ONLY'):(s==='NONE'?'NO_BREAK':'AMBIGUOUS'),firstWickSide:ws,firstWickOpenMinute:wi<0?null:510+wi*5,firstCloseSide:cs,firstCloseOpenMinute:ci<0?null:510+ci*5,signalIndex:i,signalOpenMinute:minute,signalCloseMinute:closeMinute,signalOpenTime:mt(minute),signalCloseTime:mt(closeMinute),timeBlock:block,minutesRemaining:closeMinute==null?null:960-closeMinute,signalOpen:signal?.open??null,signalHigh:signal?.high??null,signalLow:signal?.low??null,signalClose:signal?.close??null,nextOpen:next?.open??null,wickOvershoot:resolved?aligned(extreme):null,closeOvershoot:resolved?aligned(signal.close):null,wickOvershootBin:resolved?tenth(aligned(extreme)):null,closeOvershootBin:resolved?tenth(aligned(signal.close)):null,firstCloseAfterWickMinutes:wi>=0&&ci>=0?(ci-wi)*5:null,eodClose:end,eodCloseKnownMinute:960,eodBoxState:boxState,eodState:resolved?(boxState==='INSIDE'?'INSIDE':(s==='U'?boxState==='ABOVE':boxState==='BELOW')?'SAME_SIDE':'OPPOSITE_SIDE'):null,finalSignedFromOpen:resolved?(s==='U'?end-open:open-end)/w:null,finalSideMultiple:resolved?1+aligned(end):null,finalOutsideDistance:resolved?aligned(end):null,maxLaterSameSideOvershoot:resolved?Math.max(0,lateExtreme==null?0:aligned(lateExtreme)):null,maxLaterSameSideMultiple:resolved&&lateExtreme!=null?1+aligned(lateExtreme):null,maxSessionSameSideOvershoot:resolved?Math.max(0,...b.map(x=>aligned(s==='U'?x.high:x.low))):null,additionalBeyondSignalExtreme:resolved?Math.max(0,lateExtreme==null?0:(s==='U'?lateExtreme-extreme:extreme-lateExtreme)/w):null,laterBars:later.length};
 for(const [k,v]of Object.entries(expected))equal(e[k],v,k,id);
 result.eventRows++;result.marketEvents[e.market]=(result.marketEvents[e.market]||0)+1;
 const tags=[e.market,e.eventKind,s,e.type,closeMinute===960?'terminal16':null,closeMinute!=null&&closeMinute>=900?'late15':null,closeMinute!=null&&closeMinute<570?'early':null].filter(Boolean);
 for(const tag of tags){result.edgeCounts[tag]=(result.edgeCounts[tag]||0)+1;if(!sampleCandidates.has(tag))sampleCandidates.set(tag,e);}
 for(const multiple of LEVELS){
  const target=resolved?(s==='U'?l+multiple*w:u-multiple*w):null,hit=x=>s==='U'?x.high>=target-EPS:x.low<=target+EPS;
  const trigger=resolved?hit(signal):null,before=resolved&&i>0?b.slice(0,i).some(hit):false,through=resolved?before||trigger:null,gap=resolved&&!!next&&!through&&(s==='U'?next.open>=target-EPS:next.open<=target+EPS),none=resolved&&!next,pending=resolved&&!through&&!gap&&!!next;
  const li=resolved?later.findIndex(hit):-1,at=li<0?null:510+5*(i+1+li),fi=resolved?b.findIndex(hit):-1;
  const t={multiple,target,triggerReached:trigger,touchedBeforeSignal:resolved?before:null,touchedBeforeFirstClose:e.eventKind==='CLOSE_FIRST'?before:null,touchedThroughSignal:through,nextOpenGap:gap,noRemaining:none,pending,laterHit:resolved?li>=0:null,pendingHit:pending?li>=0:null,laterHitOpenMinute:at,laterHitCloseMinute:at==null?null:at+5,firstTargetHitOpenMinute:fi<0?null:510+5*fi};
  expectations.set(id+'|'+multiple,t);
  for(const [tag,value]of [['triggerReached',trigger],['nextOpenGap',gap],['firstCloseEarlierHit',e.eventKind==='CLOSE_FIRST'&&before],['pendingHit',pending&&li>=0],['pendingMiss',pending&&li<0]])if(value){result.edgeCounts[tag]=(result.edgeCounts[tag]||0)+1;if(!sampleCandidates.has(tag))sampleCandidates.set(tag,{...e,auditedTarget:t});}
 }
}
for await(const line of readline.createInterface({input:createReadStream(OUT+'/targets.jsonl'),crlfDelay:Infinity})){
 if(!line)continue;const r=JSON.parse(line),id=r.eventId+'|'+r.multiple,expected=expectations.get(id);assert(expected,'Unexpected/duplicate target '+id);
 for(const [k,v]of Object.entries(expected))equal(r[k],v,k,id);
 expectations.delete(id);result.targetRows++;
}
assert.equal(expectations.size,0,'Missing targets');assert.equal(result.targetRows,result.eventRows*LEVELS.length);
const seen=new Set();for(const [reason,e]of sampleCandidates)if(!seen.has(e.eventId)){seen.add(e.eventId);result.samples.push({reason,eventId:e.eventId,market:e.market,date:e.date,contract:e.contract,eventKind:e.eventKind,side:e.side,type:e.type,signalOpenTime:e.signalOpenTime,signalCloseTime:e.signalCloseTime,eodClose:e.eodClose,eodState:e.eodState,laterBars:e.laterBars,auditedTarget:e.auditedTarget});}

// Native CSV parity checks use the original UTC timestamps and exact price rows.
const continuation=await json('outputs/continuation-results.json'),nativeByCL=new Map(continuation.map(x=>[x.date,x.sourceCsv]));
const format=new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
const select=[];
for(const market of ['CL','NQ','ES','GC']){
 const available=[...days[market].values()].filter(d=>d.date>='2026-01-01'&&d.bars[245]);
 for(const d of [available[0],available.at(-1)])if(d)select.push({market,d});
}
for(const {market,d}of select){
 let paths;if(market==='CL')paths=[nativeByCL.get(d.date)].filter(Boolean);else paths=(await fs.readdir(`outputs/${market.toLowerCase()}-database/raw`)).filter(x=>x.startsWith(d.contract+'-')&&x.endsWith('.csv')).map(x=>`outputs/${market.toLowerCase()}-database/raw/${x}`);
 const parity=[];
 for(const p of paths){const content=await fs.readFile(p,'utf8'),lines=content.replace(/^\uFEFF/,'').trim().split(/\r?\n/),head=lines.shift().split(',').map(x=>x.replaceAll('"','')),indexes=['time','open','high','low','close'].map(x=>head.indexOf(x));assert(indexes.every(x=>x>=0));
  const dayUTC=Date.parse(d.date+'T00:00:00Z')/1000;
  for(const line of lines){const c=line.split(','),epoch=Number(c[indexes[0]]);if(epoch<dayUTC+17*3600||epoch>dayUTC+22*3600)continue;
   const parts=Object.fromEntries(format.formatToParts(new Date(epoch*1000)).map(x=>[x.type,x.value]));if(`${parts.year}-${parts.month}-${parts.day}`!==d.date||parts.hour!=='15'||parts.minute!=='55')continue;
   const actual=Object.fromEntries(['open','high','low','close'].map((k,i)=>[k,Number(c[indexes[i+1]])]));for(const k of ['open','high','low','close'])equal(actual[k],d.bars[245][k],'native '+k,market+'|'+d.date);
   parity.push({path:p,epoch,NY:'15:55',...actual,sha256:createHash('sha256').update(content).digest('hex')});
  }
 }
 assert(parity.length,'No native EOD parity source '+market+' '+d.date);result.nativeCSVParity.push({market,date:d.date,contract:d.contract,eodClose:d.bars[245].close,matches:parity});
}
for(const p of ['events.jsonl','targets.jsonl'])result.files[p]={sha256:createHash('sha256').update(await fs.readFile(OUT+'/'+p)).digest('hex')};
result.finishedUTC=new Date().toISOString();result.status='PASS';assert(result.samples.length>=10,'Need at least ten diverse event samples');
await fs.writeFile(OUT+'/audit.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({status:result.status,eventRows:result.eventRows,targetRows:result.targetRows,checks:result.checks,samples:result.samples.length,nativeCSVParity:result.nativeCSVParity.length,edgeCounts:result.edgeCounts}));
