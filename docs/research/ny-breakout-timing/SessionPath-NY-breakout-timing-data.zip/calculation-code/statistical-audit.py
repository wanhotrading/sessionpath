"""Independent reconstruction of the saved chronological NY timing experiment."""
import collections
import csv
import hashlib
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent / 'python-packages'))
import numpy as np

ROOT = Path('outputs/ny-breakout-timing')
analysis = json.loads((ROOT / 'analysis.json').read_text(encoding='utf-8'))
events = [json.loads(line) for line in (ROOT / 'events.jsonl').read_text(encoding='utf-8').splitlines() if line]
with (ROOT / 'walk-forward-predictions.csv').open(encoding='utf-8-sig', newline='') as handle:
    actual = list(csv.DictReader(handle))
for row in actual:
    for key in ['y', 'p_base', 'p_candidate']:
        row[key] = json.loads(row[key])
    for key in ['base_n', 'local_n', 'n', 'timeBlock']:
        row[key] = int(row[key])

checks = 0
def near(actual_value, expected, label):
    global checks
    checks += 1
    if isinstance(expected, list):
        assert len(actual_value) == len(expected), label
        for a, e in zip(actual_value, expected):
            near(a, e, label)
    elif isinstance(expected, (float, np.floating)):
        assert abs(actual_value - expected) < 1e-12, (label, actual_value, expected)
    else:
        assert actual_value == expected, (label, actual_value, expected)

STATES = ['INSIDE', 'SAME_SIDE', 'OPPOSITE_SIDE']
models = ['time_block', 'close_strength', 'time_strength']
outcomes = ['pending150', 'eod3']
markets = ['CL', 'NQ', 'ES', 'GC']
saved = {(r['market'], r['outcome'], r['model'], r['eventId']): r for r in actual}
assert len(saved) == len(actual)
expected_keys = set()
chronology = []

# This is separate code, with no import of analyze.py or its predictions_for function.
for market in markets:
    source = sorted([r for r in events if r['market'] == market and r['method'] == 'nyOwnWide' and r['eventKind'] == 'WICK_FIRST' and r['n'] >= 50], key=lambda r: r['date'])
    assert len({r['date'] for r in source}) == len(source)
    paired = {}
    for outcome in outcomes:
        for model in models:
            base_counts, local_counts = {}, {}
            base_dates, local_dates = collections.defaultdict(list), collections.defaultdict(list)
            made = []
            min_gap = None
            for event in source:
                if event['side'] not in ('U', 'D'):
                    continue
                if outcome == 'pending150':
                    t = next(t for t in event['targets'] if abs(t['multiple'] - 1.5) < 1e-12)
                    if not t['pending']:
                        continue
                    assert event['minutesRemaining'] > 0 and not t['touchedThroughSignal'] and not t['nextOpenGap']
                    observed = int(t['pendingHit'])
                    vector = [1 - observed, observed]
                else:
                    if event['minutesRemaining'] <= 0 or event['eodState'] not in STATES:
                        continue
                    observed = [int(event['eodState'] == state) for state in STATES]
                    vector = observed
                strength = 'CLOSED_INSIDE' if event['type'] == 'WICK_ONLY' else str(round(event['closeOvershootBin'] * 100)) + '%'
                categories = (str(event['timeBlock']),) if model == 'time_block' else (strength,) if model == 'close_strength' else (str(event['timeBlock']), strength)
                group = (event['side'], event['type'])
                cell = group + categories
                dimensions = len(vector)
                baseline = base_counts.setdefault(group, [0] * dimensions)
                local = local_counts.setdefault(cell, [0] * dimensions)
                n, ln = sum(baseline), sum(local)
                p = [(c + 1) / (n + dimensions) for c in baseline]
                q = [(c + 20 * prior) / (ln + 20) for c, prior in zip(local, p)]
                # Every outcome in both denominators must precede the prediction date.
                assert all(d < event['date'] for d in base_dates[group])
                assert all(d < event['date'] for d in local_dates[cell])
                if event['date'] >= '2024-01-01' and n >= 50:
                    key = (market, outcome, model, event['eventId'])
                    row = saved[key]
                    expected_keys.add(key)
                    for field, value in {'method': 'nyOwnWide', 'eventKind': 'WICK_FIRST', 'date': event['date'], 'side': event['side'], 'type': event['type'], 'category': ';'.join(categories), 'timeBlock': event['timeBlock'], 'strength': strength, 'n': event['n'], 'base_n': n, 'local_n': ln, 'y': observed, 'p_base': p[1] if dimensions == 2 else p, 'p_candidate': q[1] if dimensions == 2 else q}.items():
                        near(row[field], value, (key, field))
                    made.append(event['eventId'])
                    if base_dates[group]:
                        gap = (np.datetime64(event['date']) - np.datetime64(base_dates[group][-1])).astype(int)
                        min_gap = int(gap) if min_gap is None else min(min_gap, int(gap))
                for j in range(dimensions):
                    baseline[j] += vector[j]
                    local[j] += vector[j]
                base_dates[group].append(event['date'])
                local_dates[cell].append(event['date'])
            if outcome in paired:
                assert paired[outcome] == made, 'Nonpaired candidates'
            else:
                paired[outcome] = made
            chronology.append({'market': market, 'outcome': outcome, 'model': model, 'n': len(made), 'minimum_calendar_days_from_latest_training_outcome': min_gap})
assert expected_keys == set(saved), 'Missing/unexpected saved predictions'

comparisons = {(r['market'], r['outcome'], r['model']): r for r in analysis['comparisons']}
assert len(comparisons) == 24
groups = collections.defaultdict(list)
for row in actual:
    groups[(row['market'], row['outcome'], row['model'])].append(row)

recalculated = []
for key, rows in groups.items():
    baseline_losses, candidate_losses = [], []
    for row in rows:
        b, c, y = row['p_base'], row['p_candidate'], row['y']
        if not isinstance(y, list):
            b, c, y = [b], [c], [y]
        baseline_losses.append(sum((p - v) ** 2 for p, v in zip(b, y)))
        candidate_losses.append(sum((p - v) ** 2 for p, v in zip(c, y)))
    brier_b = sum(baseline_losses) / len(rows)
    brier_c = sum(candidate_losses) / len(rows)
    gains = [b - c for b, c in zip(baseline_losses, candidate_losses)]
    stats = {'n': len(rows), 'base_brier': brier_b, 'candidate_brier': brier_c, 'gain': sum(gains) / len(gains), 'relative_brier_reduction': (sum(gains) / len(gains)) / brier_b, 'mean_local_train_n': sum(r['local_n'] for r in rows) / len(rows), 'sparse_local_fraction': sum(r['local_n'] < 20 for r in rows) / len(rows)}
    for field, value in stats.items():
        near(comparisons[key][field], value, (key, field))
    recalculated.append({'market': key[0], 'outcome': key[1], 'model': key[2], **stats})

# Independent Holm step-down recomputation across all24 prespecified tests.
ordered = sorted(comparisons.values(), key=lambda r: r['bootstrap']['p'] if r['bootstrap']['p'] is not None else 1)
running = 0
for rank, row in enumerate(ordered):
    p = 1 if row['bootstrap']['p'] is None else row['bootstrap']['p']
    running = min(1, max(running, (24 - rank) * p))
    near(row['holm_p'], running, ('Holm', row['market'], row['outcome'], row['model']))

# Rebuild the calendar-block bootstrap without importing the production function.
calendar = [d for d in json.loads((ROOT / 'calendar.json').read_text(encoding='utf-8'))['union'] if d >= '2024-01-01']
calendar = sorted(set(calendar))
assert len(calendar) == analysis['calendar_dates']
positions = {d: i for i, d in enumerate(calendar)}
bootstrap_checks = []
for block in [5, 10, 20]:
    # Primary10-date seed is the frozen study seed; sensitivity seeds add block.
    generator = np.random.default_rng(analysis['seed'] if block == 10 else analysis['seed'] + block)
    starts = generator.integers(0, len(calendar), size=(analysis['bootstrap_reps'], math.ceil(len(calendar) / block)))
    picks = ((starts[:, :, None] + np.arange(block)) % len(calendar)).reshape(analysis['bootstrap_reps'], -1)[:, :len(calendar)]
    for key, rows in groups.items():
        gain_sum = np.zeros(len(calendar)); count = np.zeros(len(calendar))
        for row in rows:
            b, c, y = np.asarray(row['p_base']), np.asarray(row['p_candidate']), np.asarray(row['y'])
            value = np.sum((b - y) ** 2) - np.sum((c - y) ** 2)
            gain_sum[positions[row['date']]] += value
            count[positions[row['date']]] += 1
        denominator = count[picks].sum(axis=1)
        values = gain_sum[picks].sum(axis=1)[denominator > 0] / denominator[denominator > 0]
        observed = gain_sum.sum() / count.sum()
        lo, hi = np.quantile(values, [.025, .975])
        p = (1 + sum(abs(values - observed) >= abs(observed))) / (len(values) + 1)
        expected = comparisons[key]['bootstrap'] if block == 10 else comparisons[key]['block_sensitivity'][str(block)]
        for field, value in {'lo': float(lo), 'hi': float(hi), 'p': float(p), 'reps': len(values)}.items():
            near(expected[field], value, ('bootstrap', key, block, field))
        bootstrap_checks.append({'market': key[0], 'outcome': key[1], 'model': key[2], 'block': block, 'lo': float(lo), 'hi': float(hi), 'p': float(p)})

# A different seed for one timing model permarket/outcome is a stability spotcheck.
alternative = []
generator = np.random.default_rng(927461)
starts = generator.integers(0, len(calendar), size=(3000, math.ceil(len(calendar) / 10)))
picks = ((starts[:, :, None] + np.arange(10)) % len(calendar)).reshape(3000, -1)[:, :len(calendar)]
for key, rows in groups.items():
    if key[2] != 'time_block':
        continue
    gain_sum = np.zeros(len(calendar)); count = np.zeros(len(calendar))
    for row in rows:
        b, c, y = np.asarray(row['p_base']), np.asarray(row['p_candidate']), np.asarray(row['y'])
        gain_sum[positions[row['date']]] += np.sum((b - y) ** 2) - np.sum((c - y) ** 2)
        count[positions[row['date']]] += 1
    denominators = count[picks].sum(axis=1)
    means = gain_sum[picks].sum(axis=1)[denominators > 0] / denominators[denominators > 0]
    lo, hi = np.quantile(means, [.025, .975])
    alternative.append({'market': key[0], 'outcome': key[1], 'model': key[2], 'seed': 927461, 'reps': len(means), 'block': 10, 'lo': float(lo), 'hi': float(hi)})

supported = []
for row in comparisons.values():
    positive_years = sum(a['n'] >= 30 and a['gain'] is not None and a['gain'] > 0 for a in row['annual'])
    qualifies = row['n'] >= 100 and row['bootstrap']['lo'] is not None and row['bootstrap']['lo'] > 0 and row['holm_p'] < .05 and row['late2025']['gain'] is not None and row['late2025']['gain'] > 0 and positive_years >= 2
    classification = 'SUPPORTED' if qualifies else 'TENTATIVE' if row['gain'] is not None and row['gain'] > 0 else 'NO_IMPROVEMENT'
    near(row['classification'], classification, ('classification', row['market'], row['outcome'], row['model']))
    if qualifies:
        supported.append((row['market'], row['outcome'], row['model']))

report = {'status': 'PASS', 'independent_analysis_import': False, 'checks': checks, 'predictions': len(actual), 'primary_comparisons': len(comparisons), 'terminal_signal_predictions': sum(1 for r in actual if r['timeBlock'] == 960), 'all_predictions_exactly_reconstructed_from_prior_event_outcomes': True, 'chronology': chronology, 'brier_and_sparse_cell_recalculation': recalculated, 'Holm_family_size': 24, 'exact_bootstrap_reproductions': bootstrap_checks, 'alternate_seed_spotchecks': alternative, 'supported': supported, 'limitations': ['This audits implementation and numerical consistency, not whether retrospective results will generalize prospectively.', 'Reported bootstrap significance remains an approximation under calendar-date block resampling.', 'EOD multiclass Brier is the sum over threeclasses; its scale must not be compared directly with binary target Brier.'], 'source_hashes': {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in ['events.jsonl', 'walk-forward-predictions.csv', 'analysis.json', 'calendar.json']}}
assert report['terminal_signal_predictions'] == 0
(ROOT / 'statistical-audit.json').write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
print(json.dumps({'status': report['status'], 'checks': checks, 'predictions': len(actual), 'exact_bootstrap_reproductions': len(bootstrap_checks), 'alternate_seed_spotchecks': len(alternative), 'supported': supported}))
